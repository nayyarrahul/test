# Real-time Video Streaming Application

This project is a comprehensive real-time video streaming application that allows users to stream live video and interact with viewers through a chat system. The application demonstrates the use of WebRTC for peer-to-peer connections and Socket.io for real-time communication.

## Table of Contents
- [Architecture Overview](#architecture-overview)
- [Cloud Integration](#cloud-integration)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Installation](#installation)
- [Usage](#usage)
- [Scalability Considerations](#scalability-considerations)
- [Latency Considerations](#latency-considerations)
- [Fault Tolerance](#fault-tolerance)
- [AWS Cloud Integration Guide](#aws-cloud-integration-guide)

## Architecture Overview

The application follows a modern web architecture with the following components:

1. **Frontend**:
   - HTML/CSS/JavaScript for the user interface
   - WebRTC for peer-to-peer video streaming
   - Socket.io client for real-time communication

2. **Backend**:
   - Node.js with Express for the web server
   - Socket.io server for managing real-time connections
   - Room-based architecture for organizing streams and participants

3. **Communication Flow**:
   - Users create or join a room with a unique ID
   - WebRTC establishes peer connections between users for video/audio
   - Socket.io handles signaling, chat messages, and user events

![Architecture Diagram](https://i.imgur.com/example-diagram.png)

## Cloud Integration

While the provided application runs locally, it is designed to be deployed to cloud services. Here's how AWS services can be integrated:

### AWS Elemental MediaLive
AWS Elemental MediaLive can be used for video transcoding and processing. It would handle:
- Ingesting the WebRTC streams
- Encoding the stream into multiple bitrates
- Applying any necessary video processing (filtering, overlays)

### AWS Elemental MediaPackage
MediaPackage would manage content packaging and delivery preparation:
- Converting streams to various formats (HLS, DASH, CMAF)
- DRM protection if required
- Time-shifted viewing capabilities

### Amazon CloudFront
CloudFront would serve as the content delivery network:
- Distributing video content with low latency globally
- Caching static assets
- Edge optimization for viewers across different regions

## Features

- Real-time video streaming using WebRTC
- Multiple participants in a single room
- Text chat alongside video
- Screen sharing capability
- Video/audio controls (mute/unmute)
- Room creation and joining via unique IDs
- Responsive design for different devices

## Technologies Used

- Node.js
- Express.js
- Socket.io
- WebRTC
- HTML5/CSS3/JavaScript

## Installation

### Prerequisites
- Node.js (v14 or newer)
- NPM (v6 or newer)

### Steps
1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/video-streaming-app.git
   cd video-streaming-app
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Start the server
   ```bash
   npm start
   ```

4. Open your browser and navigate to `http://localhost:3000`

## Usage

1. **Creating a Stream**:
   - Click on "Create a New Stream" on the homepage
   - Share the provided Room ID with viewers

2. **Joining a Stream**:
   - Enter the Room ID in the input field
   - Click "Join Stream"

3. **Controls**:
   - Toggle video: Turn your camera on/off
   - Toggle audio: Mute/unmute your microphone
   - Share screen: Share your screen with viewers
   - Leave: Exit the current stream

## Scalability Considerations

This application demonstrates important scalability considerations for real-time applications:

1. **Horizontal Scaling**:
   - The Node.js server can be deployed across multiple instances behind a load balancer
   - Socket.io can be configured with Redis adapter for multi-server setups
   - WebRTC traffic can be offloaded with TURN servers in different regions

2. **Resource Efficiency**:
   - Peer-to-peer connections reduce server bandwidth requirements
   - Room-based architecture isolates resources by session
   - Optimized media bitrates based on network conditions

3. **AWS Scaling Strategies**:
   - Auto-scaling groups for server instances
   - MediaLive channel replication for handling increased transcoding loads
   - CloudFront edge location distribution for global reach

## Latency Considerations

Minimizing latency is crucial for real-time applications:

1. **Connection Optimization**:
   - WebRTC direct peer connections minimize intermediary delays
   - ICE candidates negotiation for optimal path finding
   - STUN server integration for NAT traversal

2. **Transport Layer**:
   - WebSockets for persistent connections
   - UDP-based media transfer via WebRTC
   - Optimized packet sizes for video/audio

3. **AWS Latency Reduction**:
   - CloudFront edge locations for content caching
   - MediaLive regional deployment for closer ingestion points
   - Regional API endpoints for signaling

## Fault Tolerance

The application implements several fault tolerance strategies:

1. **Connection Recovery**:
   - Automatic reconnection attempts for dropped WebSocket connections
   - ICE connection monitoring and restart
   - Graceful degradation (e.g., disabling video but keeping audio)

2. **State Management**:
   - Server-side room state tracking
   - Participant status monitoring
   - Message buffering for reconnecting clients

3. **AWS Fault Tolerance**:
   - MediaLive channel redundancy
   - Multi-AZ deployment for backend services
   - CloudFront redundant edge locations

## AWS Cloud Integration Guide

To deploy this application to AWS with full cloud integration:

### 1. Prepare AWS Resources
- Set up EC2 instances or ECS containers for the Node.js server
- Configure MediaLive channels for stream ingestion
- Create MediaPackage channels for content packaging
- Set up CloudFront distribution with appropriate origins

### 2. Modify the Application

Add AWS SDK integration:
```javascript
// AWS integration examples (pseudocode)
const AWS = require('aws-sdk');
const medialive = new AWS.MediaLive();
const mediapackage = new AWS.MediaPackage();

// When a high-quality stream is needed
function createMediaLiveChannel(streamId) {
  const params = {
    // MediaLive configuration
  };
  return medialive.createChannel(params).promise();
}
```

### 3. Configure MediaLive Input

```javascript
// Configure MediaLive input for WebRTC ingest
const webrtcInput = {
  Name: `webrtc-input-${streamId}`,
  Type: 'WEBRTC',
  // Additional configurations
};
```

### 4. Set up MediaPackage Output

```javascript
// Configure MediaPackage for adaptive streaming
const packagingConfig = {
  Id: `package-${streamId}`,
  PackagingGroupId: 'live-streams-group',
  // HLS, DASH configurations
};
```

### 5. CloudFront Distribution

```javascript
// Set up CloudFront distribution for content delivery
const cloudfrontConfig = {
  Origins: {
    Items: [
      {
        DomainName: `${mediapackageEndpoint}.mediapackage.${region}.amazonaws.com`,
        // Origin configuration
      }
    ]
  },
  // Distribution settings
};
```

This deployment architecture ensures scalability, low latency, and fault tolerance across a global infrastructure.
