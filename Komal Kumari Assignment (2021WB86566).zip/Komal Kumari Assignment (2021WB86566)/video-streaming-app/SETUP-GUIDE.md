# Application Setup and Usage Guide

This guide provides detailed instructions on how to set up, run, and use the real-time video streaming application.

## Prerequisites

Before setting up the application, ensure you have the following installed:

1. **Node.js** (v14.0.0 or higher)
   - Download and install from [nodejs.org](https://nodejs.org/)
   - Verify installation with `node --version`

2. **NPM** (v6.0.0 or higher, comes with Node.js)
   - Verify installation with `npm --version`

3. **Modern Web Browser**
   - Google Chrome (recommended, version 80+)
   - Mozilla Firefox (version 78+)
   - Microsoft Edge (Chromium-based, version 80+)

4. **Development Tools** (optional for modifications)
   - Git
   - Visual Studio Code or another code editor

## Installation Steps

Follow these steps to install and run the application locally:

### 1. Clone or Download the Application

```bash
# Using Git
git clone https://github.com/yourusername/video-streaming-app.git
cd video-streaming-app

# Or download and extract the ZIP file
# Then navigate to the extracted folder
```

### 2. Install Dependencies

```bash
npm install
```

This will install all required dependencies including:
- Express.js (web server)
- Socket.io (real-time communication)
- UUID (unique ID generation)
- Nodemon (for development)

### 3. Start the Server

For production:
```bash
npm start
```

For development (with automatic restart):
```bash
npm run dev
```

### 4. Access the Application

Open your web browser and navigate to:
```
http://localhost:3000
```

The application should now be running and accessible locally.

## Using the Application

### Creating a New Stream

1. From the homepage, click the "Create a New Stream" button
2. You'll be redirected to a new room with a unique Room ID
3. Allow camera and microphone access when prompted
4. Your stream is now live and ready to share

### Sharing Your Stream

1. In the streaming room, note the Room ID displayed at the top
2. Click the "Copy" button next to the Room ID
3. Share this ID with viewers who want to join your stream
4. Alternatively, you can share the direct room URL

### Joining a Stream

1. From the homepage, enter the Room ID in the input field
2. Click "Join Stream"
3. Allow camera and microphone access when prompted
4. You'll join the existing stream and can interact with others

### Using Stream Controls

In the streaming room, you have several controls available:

- **Toggle Video**: Turn your camera on/off
- **Toggle Audio**: Mute/unmute your microphone
- **Share Screen**: Share your entire screen or a specific application window
- **Leave**: Exit the stream and return to the homepage

### Using the Chat

The chat panel on the right side allows you to:

1. Send text messages to all participants
2. View messages from other participants
3. See system notifications (e.g., when users join/leave)

## Troubleshooting

### Camera/Microphone Access Issues

If you encounter issues with camera or microphone access:

1. Check browser permissions:
   - Click the lock/info icon in the URL bar
   - Ensure camera and microphone permissions are allowed
   
2. Verify device connections:
   - Make sure cameras/microphones are properly connected
   - Try using different USB ports if applicable
   
3. Check for other applications using the camera:
   - Close other video applications that might be using the camera

### Connection Problems

If you experience connection issues:

1. Check your internet connection
   - Test your connection speed at [speedtest.net](https://speedtest.net)
   - Ensure you have at least 1 Mbps upload speed for streaming

2. Try alternative STUN servers
   - Edit the `room.js` file to add additional STUN servers
   - Example: Add `{ urls: 'stun:stun.l.google.com:19302' }` to the iceServers array

3. Check firewall settings
   - Ensure WebRTC traffic isn't blocked by your firewall
   - UDP ports should be open for optimal WebRTC performance

### Browser Compatibility

If the application doesn't work properly in your browser:

1. Update to the latest browser version
2. Try a different supported browser
3. Check browser console for error messages (F12 key > Console tab)

## Performance Optimization

For the best streaming experience:

1. **Use a wired internet connection** instead of Wi-Fi when possible
2. **Close unused browser tabs and applications**
3. **Limit the number of simultaneous participants** (recommended: 8 or fewer)
4. **Use headphones** to prevent audio echo
5. **Position yourself in a well-lit environment** for better video quality

## AWS Deployment (Optional)

For deploying to AWS with full cloud integration, refer to the `AWS-ARCHITECTURE.md` file for detailed instructions on:

1. Setting up AWS infrastructure
2. Configuring media services
3. Deploying the application
4. Scaling and monitoring

## Additional Resources

- **WebRTC Documentation**: [webrtc.org/getting-started/overview](https://webrtc.org/getting-started/overview)
- **Socket.io Documentation**: [socket.io/docs/v4](https://socket.io/docs/v4/)
- **AWS Elemental Media Services**: [aws.amazon.com/media-services](https://aws.amazon.com/media-services/)

## Getting Support

If you encounter any issues not covered in this guide:

1. Check the GitHub repository issues section
2. Create a new issue with detailed information about your problem
3. Contact the development team at support@example.com
