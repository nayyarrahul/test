document.addEventListener('DOMContentLoaded', () => {
    const socket = io();
    const createRoomBtn = document.getElementById('create-room-btn');
    const joinRoomBtn = document.getElementById('join-room-btn');
    const roomIdInput = document.getElementById('room-id-input');
    
    // Create a new room
    createRoomBtn.addEventListener('click', () => {
        socket.emit('create-room');
    });
    
    // Handle room creation response
    socket.on('room-created', (roomId) => {
        // Navigate to the room
        window.location.href = `/room/${roomId}`;
    });
    
    // Join existing room
    joinRoomBtn.addEventListener('click', () => {
        const roomId = roomIdInput.value.trim();
        if (roomId) {
            window.location.href = `/room/${roomId}`;
        } else {
            alert('Please enter a valid Room ID');
        }
    });
    
    // Also join when pressing Enter in the input field
    roomIdInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            joinRoomBtn.click();
        }
    });
});
