document.addEventListener('DOMContentLoaded', () => {
    // Get the room ID from the URL
    const roomId = window.location.pathname.split('/').pop();
    const roomIdDisplay = document.getElementById('room-id-display');
    const copyRoomIdBtn = document.getElementById('copy-room-id');
    const toggleVideoBtn = document.getElementById('toggle-video');
    const toggleAudioBtn = document.getElementById('toggle-audio');
    const shareScreenBtn = document.getElementById('share-screen');
    const leaveBtn = document.getElementById('leave-btn');
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendMessageBtn = document.getElementById('send-message');
    const viewerCountElement = document.getElementById('viewer-count');
    const localVideo = document.getElementById('local-video');
    const remoteVideos = document.getElementById('remote-videos');
    
    // Display room ID
    roomIdDisplay.textContent = roomId;
    
    // Generate a random user ID
    const userId = `user-${Math.floor(Math.random() * 1000000)}`;
    
    // Initialize WebRTC variables
    let localStream = null;
    let screenStream = null;
    let isScreenSharing = false;
    let videoEnabled = true;
    let audioEnabled = true;
    const peers = {};
    
    // Connect to Socket.io
    const socket = io();
    
    // Initialize WebRTC
    async function initWebRTC() {
        try {
            // Get local media stream
            localStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: true
            });
            
            // Display local video
            localVideo.srcObject = localStream;
            
            // Join the room
            socket.emit('join-room', roomId, userId);
            
        } catch (error) {
            console.error('Error accessing media devices:', error);
            alert('Failed to access camera or microphone. Please check your device permissions.');
        }
    }
    
    // Update viewer count
    function updateViewerCount(participants) {
        const count = participants.length;
        viewerCountElement.textContent = `${count} ${count === 1 ? 'viewer' : 'viewers'}`;
    }
    
    // Handle incoming WebRTC connections
    socket.on('user-connected', (newUserId) => {
        console.log('User connected:', newUserId);
        connectToNewUser(newUserId);
        
        // Add system message
        addMessage({
            userId: 'system',
            content: `A new user has joined the room`,
            timestamp: new Date().toISOString()
        });
    });
    
    // Handle WebRTC signaling
    socket.on('signal', ({ userId: fromUserId, signal }) => {
        handleSignal(fromUserId, signal);
    });
    
    // Handle user disconnection
    socket.on('user-disconnected', (userId) => {
        console.log('User disconnected:', userId);
        
        // Remove the peer connection if it exists
        if (peers[userId]) {
            peers[userId].close();
            delete peers[userId];
        }
        
        // Remove the video element
        const videoElement = document.getElementById(`remote-${userId}`);
        if (videoElement) {
            videoElement.parentElement.remove();
        }
        
        // Add system message
        addMessage({
            userId: 'system',
            content: `A user has left the room`,
            timestamp: new Date().toISOString()
        });
    });
    
    // Handle room info
    socket.on('room-info', ({ participants, messages }) => {
        updateViewerCount(participants);
        
        // Display all previous messages
        messages.forEach(addMessage);
    });
    
    // Create a peer connection to a new user
    function connectToNewUser(otherUserId) {
        const peer = new SimplePeer({
            initiator: true,
            stream: localStream,
            trickle: false
        });
        
        peers[otherUserId] = peer;
        
        peer.on('signal', (signal) => {
            socket.emit('signal', { userId: otherUserId, signal });
        });
        
        peer.on('stream', (stream) => {
            addVideoStream(otherUserId, stream);
        });
        
        peer.on('close', () => {
            console.log('Peer connection closed with:', otherUserId);
        });
        
        peer.on('error', (err) => {
            console.error('Peer connection error:', err);
        });
    }
    
    // Handle incoming WebRTC signal
    function handleSignal(fromUserId, signal) {
        if (!peers[fromUserId]) {
            const peer = new SimplePeer({
                initiator: false,
                stream: localStream,
                trickle: false
            });
            
            peers[fromUserId] = peer;
            
            peer.on('signal', (signal) => {
                socket.emit('signal', { userId: fromUserId, signal });
            });
            
            peer.on('stream', (stream) => {
                addVideoStream(fromUserId, stream);
            });
            
            peer.on('close', () => {
                console.log('Peer connection closed with:', fromUserId);
            });
            
            peer.on('error', (err) => {
                console.error('Peer connection error:', err);
            });
        }
        
        try {
            peers[fromUserId].signal(signal);
        } catch (error) {
            console.error('Error handling signal:', error);
        }
    }
    
    // Add a video stream to the UI
    function addVideoStream(userId, stream) {
        const videoContainer = document.createElement('div');
        videoContainer.className = 'remote-video-container';
        videoContainer.id = `container-remote-${userId}`;
        
        const video = document.createElement('video');
        video.srcObject = stream;
        video.id = `remote-${userId}`;
        video.autoplay = true;
        video.playsInline = true;
        
        const overlay = document.createElement('div');
        overlay.className = 'video-overlay';
        overlay.innerHTML = `<span class="user-label">Viewer</span>`;
        
        videoContainer.appendChild(video);
        videoContainer.appendChild(overlay);
        remoteVideos.appendChild(videoContainer);
    }
    
    // Toggle video
    toggleVideoBtn.addEventListener('click', () => {
        videoEnabled = !videoEnabled;
        localStream.getVideoTracks().forEach(track => {
            track.enabled = videoEnabled;
        });
        toggleVideoBtn.innerHTML = videoEnabled ? 
            '<img src="/icons/video.svg" alt="Toggle Video">' : 
            '<img src="/icons/video-off.svg" alt="Toggle Video">';
    });
    
    // Toggle audio
    toggleAudioBtn.addEventListener('click', () => {
        audioEnabled = !audioEnabled;
        localStream.getAudioTracks().forEach(track => {
            track.enabled = audioEnabled;
        });
        toggleAudioBtn.innerHTML = audioEnabled ? 
            '<img src="/icons/mic.svg" alt="Toggle Audio">' : 
            '<img src="/icons/mic-off.svg" alt="Toggle Audio">';
    });
    
    // Share screen
    shareScreenBtn.addEventListener('click', async () => {
        if (!isScreenSharing) {
            try {
                screenStream = await navigator.mediaDevices.getDisplayMedia({ 
                    video: true 
                });
                
                // Replace video track
                const videoTrack = screenStream.getVideoTracks()[0];
                const senders = Object.values(peers).forEach(peer => {
                    const senders = peer._pc.getSenders();
                    const sender = senders.find(s => s.track && s.track.kind === 'video');
                    if (sender) {
                        sender.replaceTrack(videoTrack);
                    }
                });
                
                // Replace local video
                const oldStream = localVideo.srcObject;
                const audioTracks = oldStream.getAudioTracks();
                localStream = new MediaStream([videoTrack, ...audioTracks]);
                localVideo.srcObject = localStream;
                
                // Handle screen share ending
                videoTrack.onended = () => {
                    shareScreenBtn.click();
                };
                
                isScreenSharing = true;
                shareScreenBtn.innerHTML = '<img src="/icons/screen-off.svg" alt="Stop Sharing">';
                
            } catch (error) {
                console.error('Error sharing screen:', error);
                alert('Failed to share screen. Please check your device permissions.');
            }
        } else {
            // Stop screen sharing
            screenStream.getTracks().forEach(track => track.stop());
            
            // Get camera again
            navigator.mediaDevices.getUserMedia({ video: true, audio: true })
                .then(stream => {
                    const videoTrack = stream.getVideoTracks()[0];
                    
                    // Replace video track in all peer connections
                    Object.values(peers).forEach(peer => {
                        const senders = peer._pc.getSenders();
                        const sender = senders.find(s => s.track && s.track.kind === 'video');
                        if (sender) {
                            sender.replaceTrack(videoTrack);
                        }
                    });
                    
                    // Replace local video
                    const oldStream = localVideo.srcObject;
                    const audioTracks = oldStream.getAudioTracks();
                    localStream = new MediaStream([videoTrack, ...audioTracks]);
                    localVideo.srcObject = localStream;
                    
                    isScreenSharing = false;
                    shareScreenBtn.innerHTML = '<img src="/icons/screen.svg" alt="Share Screen">';
                })
                .catch(error => {
                    console.error('Error accessing camera after screen share:', error);
                });
        }
    });
    
    // Leave room
    leaveBtn.addEventListener('click', () => {
        // Close all peer connections
        Object.values(peers).forEach(peer => peer.destroy());
        
        // Stop all local media tracks
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
        }
        
        if (screenStream) {
            screenStream.getTracks().forEach(track => track.stop());
        }
        
        // Navigate back to home
        window.location.href = '/';
    });
    
    // Copy room ID
    copyRoomIdBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(roomId)
            .then(() => {
                copyRoomIdBtn.textContent = 'Copied!';
                setTimeout(() => {
                    copyRoomIdBtn.textContent = 'Copy';
                }, 2000);
            })
            .catch(err => {
                console.error('Failed to copy room ID:', err);
            });
    });
    
    // Handle new messages
    socket.on('new-message', (message) => {
        addMessage(message);
    });
    
    // Add a message to the chat
    function addMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = `message ${message.userId === userId ? 'own' : ''}`;
        
        let senderName = 'User';
        if (message.userId === 'system') {
            senderName = 'System';
        } else if (message.userId === userId) {
            senderName = 'You';
        }
        
        const timestamp = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = `
            <div class="sender">${senderName}</div>
            <div class="content">${escapeHTML(message.content)}</div>
            <div class="timestamp">${timestamp}</div>
        `;
        
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Send message
    sendMessageBtn.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            socket.emit('send-message', message);
            messageInput.value = '';
            messageInput.focus();
        }
    });
    
    // Send message on Enter
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessageBtn.click();
        }
    });
    
    // Helper function to escape HTML
    function escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Initialize
    initWebRTC();
    
    // Simple Peer implementation for WebRTC connections
    function SimplePeer({ initiator, stream, trickle }) {
        const pc = new RTCPeerConnection({
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' },
            ]
        });
        
        // Add local stream tracks to peer connection
        if (stream) {
            stream.getTracks().forEach(track => pc.addTrack(track, stream));
        }
        
        const peer = {
            _pc: pc,
            
            signal(data) {
                if (data.type === 'offer') {
                    pc.setRemoteDescription(new RTCSessionDescription(data))
                        .then(() => pc.createAnswer())
                        .then(answer => pc.setLocalDescription(answer))
                        .then(() => {
                            const signal = pc.localDescription;
                            this._onSignal(signal);
                        })
                        .catch(err => this._onError(err));
                } else if (data.type === 'answer') {
                    pc.setRemoteDescription(new RTCSessionDescription(data))
                        .catch(err => this._onError(err));
                } else if (data.candidate) {
                    pc.addIceCandidate(new RTCIceCandidate(data))
                        .catch(err => this._onError(err));
                }
            },
            
            destroy() {
                pc.close();
            },
            
            close() {
                this.destroy();
                this._onClose();
            },
            
            on(event, callback) {
                if (event === 'signal') {
                    this._onSignal = callback;
                } else if (event === 'stream') {
                    this._onStream = callback;
                } else if (event === 'close') {
                    this._onClose = callback;
                } else if (event === 'error') {
                    this._onError = callback;
                }
            },
            
            _onSignal: () => {},
            _onStream: () => {},
            _onClose: () => {},
            _onError: (err) => console.error(err)
        };
        
        // Handle ICE candidates
        pc.onicecandidate = (event) => {
            if (event.candidate) {
                peer._onSignal({
                    candidate: event.candidate
                });
            }
        };
        
        // Handle incoming stream
        pc.ontrack = (event) => {
            peer._onStream(event.streams[0]);
        };
        
        // If initiator, create and send offer
        if (initiator) {
            pc.createOffer()
                .then(offer => pc.setLocalDescription(offer))
                .then(() => {
                    const signal = pc.localDescription;
                    peer._onSignal(signal);
                })
                .catch(err => peer._onError(err));
        }
        
        return peer;
    }
});
