const express = require('express');
const http = require('http');
const path = require('path');
const socketIo = require('socket.io');
const { v4: uuidv4 } = require('uuid');

// Initialize Express app and create HTTP server
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Store active rooms and connected users
const rooms = {};
const users = {};

// Socket.io connection handling
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);
    
    // User joins a room (either creates or joins existing)
    socket.on('join-room', (roomId, userId) => {
        // Join the room
        socket.join(roomId);
        users[socket.id] = { userId, roomId };
        
        // Initialize room if it doesn't exist
        if (!rooms[roomId]) {
            rooms[roomId] = {
                id: roomId,
                participants: [],
                messages: []
            };
        }
        
        // Add user to room participants
        rooms[roomId].participants.push({ id: userId, socketId: socket.id });
        
        // Broadcast to others in the room that a new user has joined
        socket.to(roomId).emit('user-connected', userId);
        
        // Send room information to the user
        socket.emit('room-info', {
            roomId,
            participants: rooms[roomId].participants,
            messages: rooms[roomId].messages
        });
        
        console.log(`User ${userId} joined room ${roomId}`);
    });
    
    // Handle user disconnection
    socket.on('disconnect', () => {
        const user = users[socket.id];
        if (user) {
            const { userId, roomId } = user;
            
            // Remove user from room participants
            if (rooms[roomId]) {
                rooms[roomId].participants = rooms[roomId].participants.filter(
                    participant => participant.socketId !== socket.id
                );
                
                // Broadcast to others in the room that user has disconnected
                socket.to(roomId).emit('user-disconnected', userId);
                
                // Clean up empty rooms
                if (rooms[roomId].participants.length === 0) {
                    delete rooms[roomId];
                    console.log(`Room ${roomId} deleted as it's empty`);
                }
            }
            
            // Remove user from users object
            delete users[socket.id];
            console.log(`User ${userId} disconnected from room ${roomId}`);
        }
        console.log('User disconnected:', socket.id);
    });
    
    // Handle WebRTC signaling
    socket.on('signal', ({ userId, signal }) => {
        const user = users[socket.id];
        if (user) {
            const { roomId } = user;
            // Forward the signal to the target user
            socket.to(roomId).emit('signal', {
                userId: user.userId,
                signal
            });
        }
    });
    
    // Handle chat messages
    socket.on('send-message', (message) => {
        const user = users[socket.id];
        if (user) {
            const { userId, roomId } = user;
            const timestamp = new Date().toISOString();
            const formattedMessage = {
                id: uuidv4(),
                userId,
                content: message,
                timestamp
            };
            
            // Store message in room history
            if (rooms[roomId]) {
                rooms[roomId].messages.push(formattedMessage);
                // Keep only last 100 messages
                if (rooms[roomId].messages.length > 100) {
                    rooms[roomId].messages.shift();
                }
            }
            
            // Broadcast message to all users in the room
            io.to(roomId).emit('new-message', formattedMessage);
        }
    });
    
    // Handle create-room request
    socket.on('create-room', () => {
        const roomId = uuidv4();
        socket.emit('room-created', roomId);
        console.log(`New room created: ${roomId}`);
    });
});

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/room/:roomId', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'room.html'));
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
