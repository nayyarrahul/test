<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Instructions for Real-time Video Streaming App

This is a real-time video streaming application built with Node.js, WebRTC, and Socket.IO. The application allows users to create and join video streaming rooms with chat functionality.

## Project Structure
- `server.js`: Main server file with Express and Socket.IO implementation
- `public/`: Frontend assets
  - `index.html`: Homepage
  - `room.html`: Video streaming room
  - `js/`: JavaScript files
  - `styles.css`: Application styling
  - `icons/`: SVG icons for UI elements

## Development Guidance

When suggesting code for this project:

1. **WebRTC Implementation**: Follow WebRTC best practices for peer connections, ICE handling, and media streaming.

2. **Real-time Communication**: Use Socket.IO for signaling and real-time events.

3. **Performance Optimization**: Prioritize low-latency solutions for video streaming.

4. **AWS Integration**: Suggest code that integrates well with AWS Elemental Media Services.

5. **Scalability Considerations**: Recommend patterns that support horizontal scaling.

6. **Error Handling**: Include robust error handling for network and device issues.

7. **Browser Compatibility**: Ensure cross-browser compatibility with modern browsers.

## Reference Documentation
- WebRTC: https://webrtc.org/getting-started/overview
- Socket.IO: https://socket.io/docs/v4/
- AWS Elemental Media Services: https://aws.amazon.com/media-services/
