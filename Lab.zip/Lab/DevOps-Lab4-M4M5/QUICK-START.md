# DevOps Lab 4 - Quick Start Guide

```
DevOps-Lab4-M4M5/
├── 📄 README.md                     # Project overview and structure
├── ⚙️ pom.xml                       # Maven configuration file
├── 🔧 Jenkinsfile                   # Jenkins pipeline configuration
├── 🚫 .gitignore                    # Git ignore rules
├── 
├── 📂 src/                          # Source code
│   ├── 📂 main/java/com/devops/lab/
│   │   ├── Application.java         # Main application class
│   │   ├── Calculator.java          # Calculator service
│   │   └── UserService.java         # User management service
│   └── 📂 test/java/com/devops/lab/
│       ├── CalculatorTest.java      # Calculator unit tests
│       └── UserServiceTest.java     # User service unit tests
│
└── 📂 documentation/                # Complete documentation
    ├── setup-guide.md               # Installation and setup guide
    ├── task1-git-setup.md           # Task 1: Git repository setup
    ├── task2-jenkins-build.md       # Task 2: Jenkins build configuration
    ├── task3-continuous-integration.md # Task 3: CI setup
    ├── task4-code-modification.md   # Task 4: CI demonstration
    └── Lab-Report-Template.md       # Report template for submission
```

## 🎯 Assignment Objectives

✅ **Task 1**: Create a Source Code Repository in Git  
✅ **Task 2**: Create a Build in Jenkins  
✅ **Task 3**: Perform Continuous Integration  
✅ **Task 4**: Perform CI through Code Modification  

## 🛠️ Prerequisites

Before starting, ensure you have installed:
- ☑️ Java JDK 11 or later
- ☑️ Apache Maven 3.6+
- ☑️ Git
- ☑️ Jenkins
- ☑️ GitHub account

## 🚀 Quick Start (Step-by-Step)

### Step 1: Setup Your Environment
1. Follow the installation guide in `documentation/setup-guide.md`
2. Verify all tools are working:
   ```bash
   java -version
   mvn -version
   git --version
   ```
3. Start Jenkins and access `http://localhost:8080`

### Step 2: Complete the Tasks
1. **Task 1** 📖 Follow `documentation/task1-git-setup.md`
   - Create GitHub repository
   - Upload this project code
   - Verify Git integration

2. **Task 2** 📖 Follow `documentation/task2-jenkins-build.md`
   - Configure Jenkins build tools
   - Create Jenkins job
   - Set up Maven build

3. **Task 3** 📖 Follow `documentation/task3-continuous-integration.md`
   - Enable SCM polling
   - Configure continuous integration
   - Verify automated polling

4. **Task 4** 📖 Follow `documentation/task4-code-modification.md`
   - Modify source code
   - Observe automatic builds
   - Demonstrate CI workflow

### Step 3: Document Your Work
1. Use `documentation/Lab-Report-Template.md` for your report
2. Take screenshots at each step
3. Fill in all required information
4. Submit your completed assignment

## 🧪 Test Your Setup

### Local Maven Build Test
```bash
cd DevOps-Lab4-M4M5
mvn clean compile test package
```

**Expected Result**: BUILD SUCCESS with 33 tests passed

### Application Test Run
```bash
java -jar target/devops-lab4-m4m5.jar
```

**Expected Output**:
```
=================================================
   DevOps Lab 4 - M4 and M5 Application
   Continuous Build and Code Quality
   Continuous Integration with Jenkins
=================================================

--- Calculator Demo ---
Number 1: 10
Number 2: 5
Addition: 10 + 5 = 15
Subtraction: 10 - 5 = 5
Multiplication: 10 * 5 = 50
Division: 10 / 5 = 2.0

--- User Service Demo ---
Username validation for 'devops_student': true
Email validation for 'student@devops.lab': true
Welcome message: Welcome to DevOps Lab, devops_student! Your continuous integration journey begins here.

✅ Application executed successfully!
Build Version: 1.0.0
Build Date: 2025-07-14T[TIME]
```

## 📋 Assignment Checklist

### Pre-Lab Setup
- [ ] Java installed and verified
- [ ] Maven installed and verified  
- [ ] Git installed and configured
- [ ] Jenkins installed and running
- [ ] GitHub account created

### Task 1: Git Repository
- [ ] Local Git repository initialized
- [ ] GitHub repository created
- [ ] Source code uploaded
- [ ] Repository structure verified
- [ ] Screenshots captured

### Task 2: Jenkins Build
- [ ] Global tools configured (JDK, Maven, Git)
- [ ] GitHub plugin installed
- [ ] Jenkins job created
- [ ] SCM configuration completed
- [ ] Maven build step added
- [ ] First build successful
- [ ] Console output documented
- [ ] Screenshots captured

### Task 3: Continuous Integration
- [ ] Poll SCM enabled
- [ ] Cron schedule configured (`* * * * *`)
- [ ] Git polling log verified
- [ ] Polling activity confirmed
- [ ] Screenshots captured

### Task 4: CI Demonstration
- [ ] Code modification #1 (version update)
- [ ] Automatic build triggered
- [ ] Code modification #2 (new feature)
- [ ] Build with tests verified
- [ ] Code modification #3 (failure test)
- [ ] Build failure detected
- [ ] Failure fixed and recovery verified
- [ ] Complete CI workflow documented
- [ ] Screenshots captured

### Documentation and Submission
- [ ] Lab report completed using template
- [ ] All screenshots included
- [ ] Technical analysis provided
- [ ] Conclusions documented
- [ ] Assignment submitted

### Common Issues and Solutions

**🔴 Maven not found**
```bash
# Add Maven to your PATH or use full path
C:\Program Files\Apache\maven\apache-maven-3.8.6\bin\mvn -version
```

**🔴 Jenkins not starting**
```bash
# Try different port
java -jar jenkins.war --httpPort=8090
```

**🔴 Git authentication issues**
- Use HTTPS with GitHub personal access token
- Or set up SSH keys

**🔴 Build failures**
- Check Java version compatibility
- Verify all dependencies are available
- Review console output for specific errors

## 🏆 Learning Outcomes

After completing this lab, you will have:
- Hands-on experience with DevOps tools (Git, Maven, Jenkins)
- Understanding of continuous integration principles
- Practical knowledge of build automation
- Skills in version control and repository management
- Experience with automated testing and quality assurance
