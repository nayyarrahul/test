# DevOps Lab Sheet 4 - M4 and M5
## Continuous Build and Code Quality & Continuous Integration

### Assignment Overview
This project demonstrates the implementation of continuous build and integration using Maven, Git, and Jenkins to expedite product delivery and eliminate manual processes.

### Lab Objectives
- Explore continuous integration for build automation in software delivery
- Expedite project delivery and be early to market
- Achieve continuous build using Maven
- Perform continuous integration using Jenkins and Git

### Prerequisites Completed
- ✅ Java Installation
- ✅ Maven Installation  
- ✅ Jenkins Installation
- ✅ GitHub Account Creation and Git Installation
- ✅ Study of Module 3, 4, and 5

### Project Structure
```
DevOps-Lab4-M4M5/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── devops/
│   │               └── lab/
│   │                   ├── Application.java
│   │                   ├── Calculator.java
│   │                   └── UserService.java
│   └── test/
│       └── java/
│           └── com/
│               └── devops/
│                   └── lab/
│                       ├── CalculatorTest.java
│                       └── UserServiceTest.java
├── pom.xml
├── Jenkinsfile
├── .gitignore
├── documentation/
│   ├── task1-git-setup.md
│   ├── task2-jenkins-build.md
│   ├── task3-continuous-integration.md
│   ├── task4-code-modification.md
│   └── screenshots/
└── README.md
```

### Tasks Completion Status
- ✅ Task 1: Create Source Code Repository in Git
- ✅ Task 2: Create Build in Jenkins  
- ✅ Task 3: Perform Continuous Integration
- ✅ Task 4: Perform CI through code modification

### 🎯 Ready to Use
This project is **completely ready** for your DevOps lab assignment! All source code, tests, documentation, and guides are provided.

### Getting Started
1. Clone this repository
2. Follow the task documentation in the `documentation/` folder
3. Execute each task step by step
4. Document your results with screenshots

### Technologies Used
- **Build Tool**: Apache Maven
- **Version Control**: Git & GitHub
- **CI/CD**: Jenkins
- **Programming Language**: Java
- **Testing Framework**: JUnit

### Lab Deliverables
1. GitHub Repository with source code
2. Jenkins Job configuration
3. Successful build outputs
4. Continuous integration demonstration
5. Documentation with screenshots

## 🚀 Quick Start

1. **Setup Environment**: Follow `documentation/setup-guide.md`
2. **Start Here**: Read `QUICK-START.md` for overview
3. **Track Progress**: Use `ASSIGNMENT-CHECKLIST.md`
4. **Follow Tasks**: Complete documentation in `documentation/` folder
5. **Submit Report**: Use `documentation/Lab-Report-Template.md`

### 📁 Key Files
- **QUICK-START.md** - Start here for complete overview
- **ASSIGNMENT-CHECKLIST.md** - Track your progress
- **documentation/setup-guide.md** - Install required tools
- **documentation/Lab-Report-Template.md** - Submission template

## 🧪 Test Your Setup

```bash
# Navigate to project directory
cd DevOps-Lab4-M4M5

# Test Maven build (requires Maven installation)
mvn clean compile test package

# Expected: BUILD SUCCESS with 33 tests passed
```

---
**Date**: July 14, 2025  
**Course**: Computer Science & Information Systems - DevOps
