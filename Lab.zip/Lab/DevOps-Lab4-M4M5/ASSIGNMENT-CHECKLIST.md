# DevOps Lab 4 - Assignment Checklist

**Student Name**: ________________________________  
**Student ID**: ____________________  
**Start Date**: ____________________  
**Completion Date**: ____________________  

---

## 📋 Pre-Lab Requirements

### Software Installation
- [ ] **Java JDK 11+** installed and verified (`java -version`)
- [ ] **Apache Maven 3.6+** installed and verified (`mvn -version`)
- [ ] **Git** installed and configured (`git --version`)
- [ ] **Jenkins** installed and running (`http://localhost:8080`)
- [ ] **GitHub account** created and accessible

### Environment Verification
- [ ] All tools accessible from command line
- [ ] JAVA_HOME environment variable set
- [ ] Maven PATH configured
- [ ] Git user name and email configured
- [ ] Jenkins initial setup completed

**Notes**: ________________________________________________

---

## 📝 Task 1: Create Source Code Repository in Git

### Git Repository Setup
- [ ] Local Git repository initialized (`git init`)
- [ ] Git user configuration completed
- [ ] Initial project files added (`git add .`)
- [ ] First commit created with descriptive message
- [ ] GitHub repository created online

### GitHub Integration
- [ ] Remote origin added (`git remote add origin [URL]`)
- [ ] Code pushed to GitHub (`git push -u origin main`)
- [ ] Repository accessible at: ___________________________
- [ ] Repository structure verified online
- [ ] README.md displays correctly

### Screenshots Captured
- [ ] Git initialization in terminal
- [ ] GitHub repository creation page
- [ ] First commit and push
- [ ] GitHub repository with files
- [ ] Repository structure view

**GitHub Repository URL**: ___________________________  
**Initial Commit Hash**: ___________________________  
**Completion Time**: ___________________________  

---

## 🔧 Task 2: Create Build in Jenkins

### 2a: Global Tool Configuration
- [ ] Jenkins Global Tool Configuration accessed
- [ ] **JDK configured**:
  - Name: ___________________________
  - Path: ___________________________
- [ ] **Maven configured**:
  - Name: ___________________________
  - Path: ___________________________
- [ ] **Git configured** (if needed):
  - Path: ___________________________
- [ ] Configuration saved and verified

### 2b: GitHub Plugin Installation
- [ ] Jenkins Plugin Manager accessed
- [ ] GitHub Integration Plugin searched
- [ ] Plugin installed successfully
- [ ] Installation verified in Installed Plugins

### 2c: Jenkins Job Creation
- [ ] New Item created in Jenkins
- [ ] Job name: **DevOps-Lab4-Build**
- [ ] Project type: **Freestyle project**
- [ ] Job description added
- [ ] Job created successfully

### 2d: Source Code Management Setup
- [ ] Git option selected in SCM
- [ ] Repository URL configured: ___________________________
- [ ] Branch specifier set: `*/main`
- [ ] Credentials configured (if needed)
- [ ] Repository browser set to GitHub

### 2e: Maven Build Step Configuration
- [ ] "Add build step" → "Invoke top-level Maven targets"
- [ ] Maven version selected: ___________________________
- [ ] Goals configured: `clean package`
- [ ] Build step saved

### 2f: First Build Execution
- [ ] Job configuration saved
- [ ] "Build Now" executed
- [ ] Build completed successfully
- [ ] Build status: **SUCCESS** (blue ball)
- [ ] Build number: #___________________________

### 2g: Build Verification
- [ ] Console output reviewed
- [ ] Build artifacts generated
- [ ] JAR file created: `devops-lab4-m4m5.jar`
- [ ] Test results: _________ tests run, _________ passed
- [ ] Build duration: _________ seconds

### Screenshots Captured
- [ ] Global Tool Configuration - JDK
- [ ] Global Tool Configuration - Maven  
- [ ] GitHub Plugin installation
- [ ] Job creation and configuration
- [ ] SCM configuration
- [ ] Build step configuration
- [ ] First successful build
- [ ] Console output
- [ ] Build artifacts

**Jenkins Job URL**: ___________________________  
**First Build Duration**: ___________________________  
**Test Results**: ___________________________  

---

## 🔄 Task 3: Perform Continuous Integration

### 3a: Job Configuration Access
- [ ] Jenkins job "DevOps-Lab4-Build" opened
- [ ] "Configure" option selected
- [ ] Job configuration page accessed

### 3b: Build Triggers Configuration
- [ ] "Build Triggers" section located
- [ ] "Poll SCM" option checked/enabled
- [ ] Schedule field displayed

### 3c: Cron Schedule Setup
- [ ] Schedule configured: `* * * * *` (every minute)
- [ ] Cron syntax understood and documented
- [ ] Configuration saved

### 3d: Git Polling Verification
- [ ] Job configuration saved successfully
- [ ] "Git Polling Log" accessible from job page
- [ ] First polling entry appeared
- [ ] Polling shows "No changes" status
- [ ] Polling frequency verified (every minute)

### 3e: Polling Monitoring
- [ ] Waited 5+ minutes after configuration
- [ ] Multiple polling entries in log
- [ ] Regular "No changes" messages confirmed
- [ ] Polling timestamps verify frequency
- [ ] No build triggers yet (expected)

### Screenshots Captured
- [ ] Build Triggers configuration
- [ ] Poll SCM setup with cron
- [ ] Saved configuration confirmation
- [ ] Git Polling Log first entries
- [ ] Multiple polling log entries

**Polling Start Time**: ___________________________  
**Polling Frequency Verified**: ___________________________  
**Sample Polling Log Entry**: ___________________________

---

## 🚀 Task 4: Continuous Integration through Code Modification

### 4a: First Code Modification (Version Update)
- [ ] Application.java opened for editing
- [ ] Version updated: 1.0.0 → 1.1.0
- [ ] CI demo messages added
- [ ] Changes committed locally
- [ ] Commit message: ___________________________
- [ ] Changes pushed to GitHub
- [ ] Push timestamp: ___________________________

### 4b: First Automatic Build
- [ ] Jenkins monitored for build trigger
- [ ] Build #2 triggered automatically
- [ ] Build trigger: **SCM change**
- [ ] Build completed successfully
- [ ] Build duration: _________ seconds
- [ ] Git Polling Log shows "Changes found"

### 4c: Second Code Modification (New Feature)
- [ ] Calculator.java modified (percentage method added)
- [ ] CalculatorTest.java updated (new tests added)
- [ ] Application.java updated (new feature demo)
- [ ] Changes committed locally
- [ ] Commit message: ___________________________
- [ ] Changes pushed to GitHub
- [ ] Push timestamp: ___________________________

### 4d: Second Automatic Build
- [ ] Build #3 triggered automatically
- [ ] Build completed successfully
- [ ] Test count increased: _________ tests
- [ ] New feature verified in build
- [ ] Build duration: _________ seconds

### 4e: Third Code Modification (Failure Test)
- [ ] Intentional test failure added
- [ ] Changes committed and pushed
- [ ] Commit message: ___________________________
- [ ] Push timestamp: ___________________________

### 4f: Build Failure Detection
- [ ] Build #4 triggered automatically
- [ ] Build failed as expected (**FAILURE** - red ball)
- [ ] Test failure detected and reported
- [ ] Failure reason documented
- [ ] Console output shows test failure details

### 4g: Failure Recovery
- [ ] Test failure fixed in code
- [ ] Fix committed and pushed
- [ ] Commit message: ___________________________
- [ ] Build #5 triggered automatically
- [ ] Build recovered successfully (**SUCCESS** - blue ball)
- [ ] All tests passing again

### Build History Summary
| Build # | Trigger | Commit Message | Result | Tests | Duration |
|---------|---------|----------------|---------|-------|----------|
| 1 | Manual | Initial build | SUCCESS | _____ | _____s |
| 2 | SCM | Version update | SUCCESS | _____ | _____s |
| 3 | SCM | New feature | SUCCESS | _____ | _____s |
| 4 | SCM | Test failure | FAILURE | _____ | _____s |
| 5 | SCM | Failure fix | SUCCESS | _____ | _____s |

### Screenshots Captured
- [ ] Code modification commits
- [ ] Build #2 automatic trigger
- [ ] Build #2 success
- [ ] Build #3 automatic trigger  
- [ ] Build #3 success with more tests
- [ ] Build #4 automatic trigger
- [ ] Build #4 failure (red ball)
- [ ] Build #4 console output (failure details)
- [ ] Build #5 recovery (green ball)
- [ ] Complete build history
- [ ] Git Polling Log with "Changes found"

**Total Builds**: _____  
**Success Rate**: _____%  
**CI Workflow Verified**: ___________________________

---

## 📄 Documentation and Submission

### Lab Report Completion
- [ ] Lab report template opened
- [ ] Executive summary completed
- [ ] Task 1 section documented
- [ ] Task 2 section documented
- [ ] Task 3 section documented
- [ ] Task 4 section documented
- [ ] Technical analysis included
- [ ] Screenshots embedded/referenced
- [ ] Conclusions written
- [ ] References added

### Final Verification
- [ ] All tasks completed successfully
- [ ] CI workflow working end-to-end
- [ ] Documentation complete
- [ ] Screenshots organized
- [ ] GitHub repository final check
- [ ] Jenkins job operational

### Submission Preparation
- [ ] Lab report finalized
- [ ] GitHub repository URL noted
- [ ] Jenkins configuration documented
- [ ] All deliverables ready

**GitHub Repository URL**: ___________________________  
**Jenkins Job URL**: ___________________________  
**Report Completion Date**: ___________________________

---

## 🎯 Final Assessment

### Technical Objectives Met
- [ ] **Source Code Repository**: Git repository with version control
- [ ] **Build Automation**: Maven build process automated in Jenkins
- [ ] **Continuous Integration**: Automatic builds on code changes
- [ ] **Quality Assurance**: Automated testing with each build
- [ ] **Failure Detection**: CI catches and reports failures
- [ ] **Recovery Process**: Quick failure resolution demonstrated

### Learning Outcomes Achieved
- [ ] **DevOps Tools**: Hands-on experience with Git, Maven, Jenkins
- [ ] **CI/CD Concepts**: Understanding of continuous integration
- [ ] **Build Automation**: Automated build and test processes
- [ ] **Version Control**: Git workflow and repository management
- [ ] **Quality Management**: Automated testing and failure detection

### Documentation Quality
- [ ] **Complete**: All sections filled out
- [ ] **Clear**: Screenshots and explanations clear
- [ ] **Accurate**: Technical details correct
- [ ] **Professional**: Report follows template structure

---

## ✅ Assignment Completion Confirmation

**Student Signature**: ________________________________  
**Completion Date**: ____________________  
**Total Time Spent**: _________ hours  

### Self-Assessment (1-5 scale)
- **Technical Understanding**: _____ / 5
- **Task Completion**: _____ / 5  
- **Documentation Quality**: _____ / 5
- **Overall Learning**: _____ / 5

### Comments/Reflections:
________________________________________________  
________________________________________________  
________________________________________________  

---

**Assignment Status**: ⬜ IN PROGRESS  ⬜ COMPLETED  ⬜ SUBMITTED

**Instructor Use Only**:
- **Grade**: _____ / 100
- **Comments**: ________________________________________________
