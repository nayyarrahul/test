package com.devops.lab;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for UserService class
 * Demonstrates service layer testing in continuous integration
 * 
 * @author DevOps Lab Student
 * @version 1.0.0
 */
@DisplayName("UserService Tests")
class UserServiceTest {
    
    private UserService userService;
    
    @BeforeEach
    void setUp() {
        userService = new UserService();
    }
    
    @Test
    @DisplayName("Test Valid Username - Normal Case")
    void testValidUsernameNormalCase() {
        // Given
        String username = "devops_student";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertTrue(result, "Valid username should return true");
    }
    
    @Test
    @DisplayName("Test Valid Username - With Numbers")
    void testValidUsernameWithNumbers() {
        // Given
        String username = "user123";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertTrue(result, "Username with numbers should be valid");
    }
    
    @Test
    @DisplayName("Test Invalid Username - Too Short")
    void testInvalidUsernameTooShort() {
        // Given
        String username = "ab";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertFalse(result, "Username shorter than 3 characters should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Username - Too Long")
    void testInvalidUsernameTooLong() {
        // Given
        String username = "this_username_is_way_too_long_for_validation";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertFalse(result, "Username longer than 20 characters should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Username - Special Characters")
    void testInvalidUsernameSpecialCharacters() {
        // Given
        String username = "user@name";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertFalse(result, "Username with special characters should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Username - Null")
    void testInvalidUsernameNull() {
        // Given
        String username = null;
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertFalse(result, "Null username should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Username - Empty")
    void testInvalidUsernameEmpty() {
        // Given
        String username = "";
        
        // When
        boolean result = userService.isValidUsername(username);
        
        // Then
        assertFalse(result, "Empty username should be invalid");
    }
    
    @Test
    @DisplayName("Test Valid Email - Normal Case")
    void testValidEmailNormalCase() {
        // Given
        String email = "student@devops.lab";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertTrue(result, "Valid email should return true");
    }
    
    @Test
    @DisplayName("Test Valid Email - With Subdomain")
    void testValidEmailWithSubdomain() {
        // Given
        String email = "test@mail.devops.lab";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertTrue(result, "Email with subdomain should be valid");
    }
    
    @Test
    @DisplayName("Test Valid Email - With Numbers")
    void testValidEmailWithNumbers() {
        // Given
        String email = "user123@example.com";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertTrue(result, "Email with numbers should be valid");
    }
    
    @Test
    @DisplayName("Test Invalid Email - Missing @ Symbol")
    void testInvalidEmailMissingAtSymbol() {
        // Given
        String email = "studentdevops.lab";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertFalse(result, "Email without @ symbol should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Email - Missing Domain")
    void testInvalidEmailMissingDomain() {
        // Given
        String email = "student@";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertFalse(result, "Email without domain should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Email - Invalid Domain")
    void testInvalidEmailInvalidDomain() {
        // Given
        String email = "student@invalid";
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertFalse(result, "Email with invalid domain should be invalid");
    }
    
    @Test
    @DisplayName("Test Invalid Email - Null")
    void testInvalidEmailNull() {
        // Given
        String email = null;
        
        // When
        boolean result = userService.isValidEmail(email);
        
        // Then
        assertFalse(result, "Null email should be invalid");
    }
    
    @Test
    @DisplayName("Test Welcome Message - Valid Username")
    void testWelcomeMessageValidUsername() {
        // Given
        String username = "devops_student";
        
        // When
        String message = userService.generateWelcomeMessage(username);
        
        // Then
        assertNotNull(message, "Welcome message should not be null");
        assertTrue(message.contains(username), "Welcome message should contain username");
        assertTrue(message.contains("Welcome"), "Welcome message should contain 'Welcome'");
        assertTrue(message.contains("DevOps Lab"), "Welcome message should contain 'DevOps Lab'");
    }
    
    @Test
    @DisplayName("Test Welcome Message - Null Username")
    void testWelcomeMessageNullUsername() {
        // Given
        String username = null;
        
        // When
        String message = userService.generateWelcomeMessage(username);
        
        // Then
        assertNotNull(message, "Welcome message should not be null");
        assertEquals("Welcome, Guest!", message, "Null username should return guest message");
    }
    
    @Test
    @DisplayName("Test Welcome Message - Empty Username")
    void testWelcomeMessageEmptyUsername() {
        // Given
        String username = "";
        
        // When
        String message = userService.generateWelcomeMessage(username);
        
        // Then
        assertNotNull(message, "Welcome message should not be null");
        assertEquals("Welcome, Guest!", message, "Empty username should return guest message");
    }
    
    @Test
    @DisplayName("Test Create User Profile - Valid Data")
    void testCreateUserProfileValidData() {
        // Given
        String username = "devops_student";
        String email = "student@devops.lab";
        
        // When
        String profile = userService.createUserProfile(username, email);
        
        // Then
        assertNotNull(profile, "User profile should not be null");
        assertTrue(profile.contains(username), "Profile should contain username");
        assertTrue(profile.contains(email), "Profile should contain email");
        assertTrue(profile.contains("✅"), "Profile should show valid indicators");
        assertTrue(profile.contains("User Profile"), "Profile should have header");
    }
    
    @Test
    @DisplayName("Test Create User Profile - Invalid Data")
    void testCreateUserProfileInvalidData() {
        // Given
        String username = "ab"; // too short
        String email = "invalid-email"; // invalid format
        
        // When
        String profile = userService.createUserProfile(username, email);
        
        // Then
        assertNotNull(profile, "User profile should not be null");
        assertTrue(profile.contains("❌"), "Profile should show invalid indicators");
        assertTrue(profile.contains("Invalid"), "Profile should indicate invalid data");
    }
    
    @Test
    @DisplayName("Test Strong Password - Valid Password")
    void testStrongPasswordValid() {
        // Given
        String password = "DevOps123!";
        
        // When
        boolean result = userService.isStrongPassword(password);
        
        // Then
        assertTrue(result, "Strong password should return true");
    }
    
    @Test
    @DisplayName("Test Strong Password - Too Short")
    void testStrongPasswordTooShort() {
        // Given
        String password = "Dev1!";
        
        // When
        boolean result = userService.isStrongPassword(password);
        
        // Then
        assertFalse(result, "Password shorter than 8 characters should be invalid");
    }
    
    @Test
    @DisplayName("Test Strong Password - Missing Uppercase")
    void testStrongPasswordMissingUppercase() {
        // Given
        String password = "devops123!";
        
        // When
        boolean result = userService.isStrongPassword(password);
        
        // Then
        assertFalse(result, "Password without uppercase should be invalid");
    }
    
    @Test
    @DisplayName("Test Strong Password - Missing Special Character")
    void testStrongPasswordMissingSpecialChar() {
        // Given
        String password = "DevOps123";
        
        // When
        boolean result = userService.isStrongPassword(password);
        
        // Then
        assertFalse(result, "Password without special character should be invalid");
    }
    
    @Test
    @DisplayName("Test Generate User ID - Not Null")
    void testGenerateUserIdNotNull() {
        // When
        String userId = userService.generateUserId();
        
        // Then
        assertNotNull(userId, "Generated user ID should not be null");
        assertTrue(userId.startsWith("USER_"), "User ID should start with 'USER_'");
        assertTrue(userId.length() > 10, "User ID should have reasonable length");
    }
    
    @Test
    @DisplayName("Test Generate User ID - Uniqueness")
    void testGenerateUserIdUniqueness() throws InterruptedException {
        // When
        String userId1 = userService.generateUserId();
        Thread.sleep(1); // Ensure different timestamps
        String userId2 = userService.generateUserId();
        
        // Then
        assertNotEquals(userId1, userId2, "Generated user IDs should be unique");
    }
}
