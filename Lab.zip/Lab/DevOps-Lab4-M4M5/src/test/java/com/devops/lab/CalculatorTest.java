package com.devops.lab;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Calculator class
 * Demonstrates test-driven development and continuous testing
 * 
 * @author DevOps Lab Student
 * @version 1.0.0
 */
@DisplayName("Calculator Tests")
class CalculatorTest {
    
    private Calculator calculator;
    
    @BeforeEach
    void setUp() {
        calculator = new Calculator();
    }
    
    @Test
    @DisplayName("Test Addition - Positive Numbers")
    void testAddPositiveNumbers() {
        // Given
        int a = 5;
        int b = 3;
        
        // When
        int result = calculator.add(a, b);
        
        // Then
        assertEquals(8, result, "5 + 3 should equal 8");
    }
    
    @Test
    @DisplayName("Test Addition - Negative Numbers")
    void testAddNegativeNumbers() {
        // Given
        int a = -5;
        int b = -3;
        
        // When
        int result = calculator.add(a, b);
        
        // Then
        assertEquals(-8, result, "-5 + (-3) should equal -8");
    }
    
    @Test
    @DisplayName("Test Addition - Zero")
    void testAddWithZero() {
        // Given
        int a = 10;
        int b = 0;
        
        // When
        int result = calculator.add(a, b);
        
        // Then
        assertEquals(10, result, "10 + 0 should equal 10");
    }
    
    @Test
    @DisplayName("Test Subtraction - Positive Result")
    void testSubtractPositiveResult() {
        // Given
        int a = 10;
        int b = 3;
        
        // When
        int result = calculator.subtract(a, b);
        
        // Then
        assertEquals(7, result, "10 - 3 should equal 7");
    }
    
    @Test
    @DisplayName("Test Subtraction - Negative Result")
    void testSubtractNegativeResult() {
        // Given
        int a = 3;
        int b = 10;
        
        // When
        int result = calculator.subtract(a, b);
        
        // Then
        assertEquals(-7, result, "3 - 10 should equal -7");
    }
    
    @Test
    @DisplayName("Test Multiplication - Positive Numbers")
    void testMultiplyPositiveNumbers() {
        // Given
        int a = 4;
        int b = 5;
        
        // When
        int result = calculator.multiply(a, b);
        
        // Then
        assertEquals(20, result, "4 * 5 should equal 20");
    }
    
    @Test
    @DisplayName("Test Multiplication - With Zero")
    void testMultiplyWithZero() {
        // Given
        int a = 10;
        int b = 0;
        
        // When
        int result = calculator.multiply(a, b);
        
        // Then
        assertEquals(0, result, "10 * 0 should equal 0");
    }
    
    @Test
    @DisplayName("Test Division - Normal Case")
    void testDivideNormalCase() {
        // Given
        int a = 10;
        int b = 2;
        
        // When
        double result = calculator.divide(a, b);
        
        // Then
        assertEquals(5.0, result, 0.001, "10 / 2 should equal 5.0");
    }
    
    @Test
    @DisplayName("Test Division - With Decimal Result")
    void testDivideWithDecimalResult() {
        // Given
        int a = 10;
        int b = 3;
        
        // When
        double result = calculator.divide(a, b);
        
        // Then
        assertEquals(3.333, result, 0.001, "10 / 3 should equal approximately 3.333");
    }
    
    @Test
    @DisplayName("Test Division by Zero - Should Throw Exception")
    void testDivideByZero() {
        // Given
        int a = 10;
        int b = 0;
        
        // When & Then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> calculator.divide(a, b),
            "Division by zero should throw IllegalArgumentException"
        );
        
        assertEquals("Cannot divide by zero", exception.getMessage());
    }
    
    @Test
    @DisplayName("Test Power - Positive Exponent")
    void testPowerPositiveExponent() {
        // Given
        int base = 2;
        int exponent = 3;
        
        // When
        double result = calculator.power(base, exponent);
        
        // Then
        assertEquals(8.0, result, 0.001, "2^3 should equal 8");
    }
    
    @Test
    @DisplayName("Test Power - Zero Exponent")
    void testPowerZeroExponent() {
        // Given
        int base = 5;
        int exponent = 0;
        
        // When
        double result = calculator.power(base, exponent);
        
        // Then
        assertEquals(1.0, result, 0.001, "5^0 should equal 1");
    }
    
    @Test
    @DisplayName("Test Square Root - Perfect Square")
    void testSqrtPerfectSquare() {
        // Given
        int number = 16;
        
        // When
        double result = calculator.sqrt(number);
        
        // Then
        assertEquals(4.0, result, 0.001, "√16 should equal 4");
    }
    
    @Test
    @DisplayName("Test Square Root - Non-Perfect Square")
    void testSqrtNonPerfectSquare() {
        // Given
        int number = 10;
        
        // When
        double result = calculator.sqrt(number);
        
        // Then
        assertEquals(3.162, result, 0.001, "√10 should equal approximately 3.162");
    }
    
    @Test
    @DisplayName("Test Square Root - Negative Number Should Throw Exception")
    void testSqrtNegativeNumber() {
        // Given
        int number = -4;
        
        // When & Then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> calculator.sqrt(number),
            "Square root of negative number should throw IllegalArgumentException"
        );
        
        assertEquals("Cannot calculate square root of negative number", exception.getMessage());
    }
    
    @Test
    @DisplayName("Test Factorial - Small Number")
    void testFactorialSmallNumber() {
        // Given
        int number = 5;
        
        // When
        long result = calculator.factorial(number);
        
        // Then
        assertEquals(120, result, "5! should equal 120");
    }
    
    @Test
    @DisplayName("Test Factorial - Zero")
    void testFactorialZero() {
        // Given
        int number = 0;
        
        // When
        long result = calculator.factorial(number);
        
        // Then
        assertEquals(1, result, "0! should equal 1");
    }
    
    @Test
    @DisplayName("Test Factorial - One")
    void testFactorialOne() {
        // Given
        int number = 1;
        
        // When
        long result = calculator.factorial(number);
        
        // Then
        assertEquals(1, result, "1! should equal 1");
    }
    
    @Test
    @DisplayName("Test Factorial - Negative Number Should Throw Exception")
    void testFactorialNegativeNumber() {
        // Given
        int number = -5;
        
        // When & Then
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> calculator.factorial(number),
            "Factorial of negative number should throw IllegalArgumentException"
        );
        
        assertEquals("Cannot calculate factorial of negative number", exception.getMessage());
    }
}
