package com.devops.lab;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main Application class for DevOps Lab 4
 * Demonstrates continuous build and integration concepts
 * 
 * @author DevOps Lab Student
 * @version 1.0.0
 * @since July 14, 2025
 */
public class Application {
    
    private static final Logger logger = LoggerFactory.getLogger(Application.class);
    
    /**
     * Main method - Entry point of the application
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        logger.info("Starting DevOps Lab 4 - Continuous Build and Integration Application");
        
        System.out.println("=================================================");
        System.out.println("   DevOps Lab 4 - M4 and M5 Application");
        System.out.println("   Continuous Build and Code Quality");
        System.out.println("   Continuous Integration with Jenkins");
        System.out.println("=================================================");
        
        // Demonstrate Calculator functionality
        Calculator calculator = new Calculator();
        demonstrateCalculator(calculator);
        
        // Demonstrate User Service functionality
        UserService userService = new UserService();
        demonstrateUserService(userService);
        
        logger.info("Application execution completed successfully");
        System.out.println("\n✅ Application executed successfully!");
        System.out.println("Build Version: 1.0.0");
        System.out.println("Build Date: " + java.time.LocalDateTime.now());
    }
    
    /**
     * Demonstrates calculator functionality
     * 
     * @param calculator Calculator instance
     */
    private static void demonstrateCalculator(Calculator calculator) {
        System.out.println("\n--- Calculator Demo ---");
        
        int a = 10, b = 5;
        System.out.println("Number 1: " + a);
        System.out.println("Number 2: " + b);
        
        System.out.println("Addition: " + a + " + " + b + " = " + calculator.add(a, b));
        System.out.println("Subtraction: " + a + " - " + b + " = " + calculator.subtract(a, b));
        System.out.println("Multiplication: " + a + " * " + b + " = " + calculator.multiply(a, b));
        System.out.println("Division: " + a + " / " + b + " = " + calculator.divide(a, b));
        
        logger.info("Calculator demo completed");
    }
    
    /**
     * Demonstrates user service functionality
     * 
     * @param userService UserService instance
     */
    private static void demonstrateUserService(UserService userService) {
        System.out.println("\n--- User Service Demo ---");
        
        String username = "devops_student";
        String email = "student@devops.lab";
        
        System.out.println("Username validation for '" + username + "': " + 
                         userService.isValidUsername(username));
        System.out.println("Email validation for '" + email + "': " + 
                         userService.isValidEmail(email));
        System.out.println("Welcome message: " + userService.generateWelcomeMessage(username));
        
        logger.info("User service demo completed");
    }
}
