package com.devops.lab;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.regex.Pattern;

/**
 * User Service class for user management operations
 * Demonstrates business logic for continuous integration testing
 * 
 * @author DevOps Lab Student
 * @version 1.0.0
 */
public class UserService {
    
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);
    
    // Regular expression patterns for validation
    private static final String EMAIL_PATTERN = 
        "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    
    private static final String USERNAME_PATTERN = "^[a-zA-Z0-9_]{3,20}$";
    
    private final Pattern emailPattern;
    private final Pattern usernamePattern;
    
    /**
     * Constructor - initializes validation patterns
     */
    public UserService() {
        this.emailPattern = Pattern.compile(EMAIL_PATTERN);
        this.usernamePattern = Pattern.compile(USERNAME_PATTERN);
        logger.info("UserService initialized with validation patterns");
    }
    
    /**
     * Validates if the provided username is valid
     * 
     * @param username Username to validate
     * @return true if username is valid, false otherwise
     */
    public boolean isValidUsername(String username) {
        logger.debug("Validating username: {}", username);
        
        if (username == null || username.trim().isEmpty()) {
            logger.warn("Username validation failed: null or empty");
            return false;
        }
        
        boolean isValid = usernamePattern.matcher(username).matches();
        logger.debug("Username validation result for '{}': {}", username, isValid);
        return isValid;
    }
    
    /**
     * Validates if the provided email is valid
     * 
     * @param email Email to validate
     * @return true if email is valid, false otherwise
     */
    public boolean isValidEmail(String email) {
        logger.debug("Validating email: {}", email);
        
        if (email == null || email.trim().isEmpty()) {
            logger.warn("Email validation failed: null or empty");
            return false;
        }
        
        boolean isValid = emailPattern.matcher(email).matches();
        logger.debug("Email validation result for '{}': {}", email, isValid);
        return isValid;
    }
    
    /**
     * Generates a welcome message for a user
     * 
     * @param username Username for the welcome message
     * @return Welcome message string
     */
    public String generateWelcomeMessage(String username) {
        logger.debug("Generating welcome message for user: {}", username);
        
        if (username == null || username.trim().isEmpty()) {
            logger.warn("Welcome message generation failed: null or empty username");
            return "Welcome, Guest!";
        }
        
        String message = "Welcome to DevOps Lab, " + username + "! Your continuous integration journey begins here.";
        logger.debug("Generated welcome message: {}", message);
        return message;
    }
    
    /**
     * Creates a user profile summary
     * 
     * @param username Username
     * @param email Email address
     * @return User profile summary
     */
    public String createUserProfile(String username, String email) {
        logger.debug("Creating user profile for username: {}, email: {}", username, email);
        
        StringBuilder profile = new StringBuilder();
        profile.append("=== User Profile ===\n");
        
        if (isValidUsername(username)) {
            profile.append("Username: ").append(username).append(" ✅\n");
        } else {
            profile.append("Username: ").append(username != null ? username : "N/A").append(" ❌ (Invalid)\n");
        }
        
        if (isValidEmail(email)) {
            profile.append("Email: ").append(email).append(" ✅\n");
        } else {
            profile.append("Email: ").append(email != null ? email : "N/A").append(" ❌ (Invalid)\n");
        }
        
        profile.append("Profile Created: ").append(java.time.LocalDateTime.now()).append("\n");
        profile.append("DevOps Lab: Continuous Integration Demo\n");
        
        String profileString = profile.toString();
        logger.debug("Created user profile: {}", profileString);
        return profileString;
    }
    
    /**
     * Validates password strength
     * 
     * @param password Password to validate
     * @return true if password meets strength requirements, false otherwise
     */
    public boolean isStrongPassword(String password) {
        logger.debug("Validating password strength");
        
        if (password == null || password.length() < 8) {
            logger.warn("Password validation failed: null or too short");
            return false;
        }
        
        boolean hasUpper = password.chars().anyMatch(Character::isUpperCase);
        boolean hasLower = password.chars().anyMatch(Character::isLowerCase);
        boolean hasDigit = password.chars().anyMatch(Character::isDigit);
        boolean hasSpecial = password.chars().anyMatch(ch -> "!@#$%^&*()_+-=[]{}|;:,.<>?".indexOf(ch) >= 0);
        
        boolean isStrong = hasUpper && hasLower && hasDigit && hasSpecial;
        logger.debug("Password strength validation result: {}", isStrong);
        return isStrong;
    }
    
    /**
     * Generates a random user ID
     * 
     * @return Random user ID
     */
    public String generateUserId() {
        String userId = "USER_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 1000);
        logger.debug("Generated user ID: {}", userId);
        return userId;
    }
}
