package com.devops.lab;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Calculator class for basic mathematical operations
 * Used to demonstrate continuous build and testing processes
 * 
 * @author DevOps Lab Student
 * @version 1.0.0
 */
public class Calculator {
    
    private static final Logger logger = LoggerFactory.getLogger(Calculator.class);
    
    /**
     * Adds two integers
     * 
     * @param a First number
     * @param b Second number
     * @return Sum of a and b
     */
    public int add(int a, int b) {
        logger.debug("Adding {} and {}", a, b);
        int result = a + b;
        logger.debug("Addition result: {}", result);
        return result;
    }
    
    /**
     * Subtracts second number from first number
     * 
     * @param a First number
     * @param b Second number
     * @return Difference of a and b
     */
    public int subtract(int a, int b) {
        logger.debug("Subtracting {} from {}", b, a);
        int result = a - b;
        logger.debug("Subtraction result: {}", result);
        return result;
    }
    
    /**
     * Multiplies two integers
     * 
     * @param a First number
     * @param b Second number
     * @return Product of a and b
     */
    public int multiply(int a, int b) {
        logger.debug("Multiplying {} and {}", a, b);
        int result = a * b;
        logger.debug("Multiplication result: {}", result);
        return result;
    }
    
    /**
     * Divides first number by second number
     * 
     * @param a Dividend
     * @param b Divisor
     * @return Quotient of a divided by b
     * @throws IllegalArgumentException if b is zero
     */
    public double divide(int a, int b) {
        logger.debug("Dividing {} by {}", a, b);
        
        if (b == 0) {
            logger.error("Division by zero attempted");
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        
        double result = (double) a / b;
        logger.debug("Division result: {}", result);
        return result;
    }
    
    /**
     * Calculates the power of a number
     * 
     * @param base Base number
     * @param exponent Exponent
     * @return base raised to the power of exponent
     */
    public double power(int base, int exponent) {
        logger.debug("Calculating {} to the power of {}", base, exponent);
        double result = Math.pow(base, exponent);
        logger.debug("Power result: {}", result);
        return result;
    }
    
    /**
     * Calculates the square root of a number
     * 
     * @param number Number to find square root of
     * @return Square root of the number
     * @throws IllegalArgumentException if number is negative
     */
    public double sqrt(int number) {
        logger.debug("Calculating square root of {}", number);
        
        if (number < 0) {
            logger.error("Square root of negative number attempted");
            throw new IllegalArgumentException("Cannot calculate square root of negative number");
        }
        
        double result = Math.sqrt(number);
        logger.debug("Square root result: {}", result);
        return result;
    }
    
    /**
     * Calculates factorial of a number
     * 
     * @param n Number to calculate factorial for
     * @return Factorial of n
     * @throws IllegalArgumentException if n is negative
     */
    public long factorial(int n) {
        logger.debug("Calculating factorial of {}", n);
        
        if (n < 0) {
            logger.error("Factorial of negative number attempted");
            throw new IllegalArgumentException("Cannot calculate factorial of negative number");
        }
        
        if (n == 0 || n == 1) {
            return 1;
        }
        
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        
        logger.debug("Factorial result: {}", result);
        return result;
    }
}
