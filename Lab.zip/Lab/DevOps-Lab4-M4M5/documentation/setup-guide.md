# DevOps Lab 4 - Setup and Installation Guide

## Prerequisites Installation Guide

This guide will help you set up all the required tools for the DevOps Lab 4 assignment.

### 1. Java Development Kit (JDK) Installation

#### Download and Install JDK 11 or later
1. **Download**: Go to [Oracle JDK](https://www.oracle.com/java/technologies/downloads/) or [OpenJDK](https://adoptium.net/)
2. **Install**: Run the installer and follow the setup wizard
3. **Set JAVA_HOME**: 
   - Windows: Add `JAVA_HOME` environment variable pointing to JDK installation directory
   - Example: `C:\Program Files\Java\jdk-11.0.x`

#### Verify Installation
```bash
java -version
javac -version
echo %JAVA_HOME%
```

Expected output:
```
java version "11.0.x" 2023-xx-xx LTS
Java(TM) SE Runtime Environment (build 11.0.x+x-LTS-xxx)
Java HotSpot(TM) 64-Bit Server VM (build 11.0.x+x-LTS-xxx, mixed mode)
```

### 2. Apache Maven Installation

#### Download and Install Maven
1. **Download**: Go to [Apache Maven](https://maven.apache.org/download.cgi)
2. **Extract**: Extract the ZIP file to a directory (e.g., `C:\Program Files\Apache\maven\apache-maven-3.8.6`)
3. **Add to PATH**: Add Maven's `bin` directory to your system PATH
   - Windows: Add `C:\Program Files\Apache\maven\apache-maven-3.8.6\bin` to PATH
4. **Set M2_HOME** (optional): Set `M2_HOME` environment variable to Maven installation directory

#### Verify Installation
```bash
mvn -version
```

Expected output:
```
Apache Maven 3.8.6 (84538c9988a25aec085021c365c560670ad80f63)
Maven home: C:\Program Files\Apache\maven\apache-maven-3.8.6
Java version: 11.0.x, vendor: Oracle Corporation
Java home: C:\Program Files\Java\jdk-11.0.x
Default locale: en_US, platform encoding: Cp1252
OS name: "windows 10", version: "10.0", arch: "amd64", family: "windows"
```

### 3. Git Installation

#### Download and Install Git
1. **Download**: Go to [Git for Windows](https://git-scm.com/download/win)
2. **Install**: Run the installer with default settings
3. **Configure**: Set up your Git identity

#### Configure Git
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

#### Verify Installation
```bash
git --version
```

Expected output:
```
git version 2.41.0.windows.1
```

### 4. Jenkins Installation

#### Option A: Download and Install Jenkins (Recommended)
1. **Download**: Go to [Jenkins Downloads](https://www.jenkins.io/download/)
2. **Windows**: Download the Windows installer (.msi file)
3. **Install**: Run the installer and follow the setup wizard
4. **Start**: Jenkins will start automatically and be available at `http://localhost:8080`

#### Option B: Run Jenkins with Java (Alternative)
1. **Download**: Download the `jenkins.war` file
2. **Run**: Execute `java -jar jenkins.war`
3. **Access**: Open `http://localhost:8080` in your browser

#### Initial Jenkins Setup
1. **Unlock Jenkins**: Use the initial admin password from the installation logs
2. **Install Plugins**: Choose "Install suggested plugins"
3. **Create Admin User**: Set up your admin account
4. **Configure Instance**: Complete the initial configuration

#### Verify Installation
- Open `http://localhost:8080` in your browser
- You should see the Jenkins dashboard

### 5. GitHub Account Setup

#### Create GitHub Account
1. **Sign Up**: Go to [GitHub](https://github.com) and create an account
2. **Verify Email**: Confirm your email address
3. **Setup Profile**: Complete your profile information

#### Configure Git with GitHub
```bash
git config --global user.name "Your GitHub Username"
git config --global user.email "your.github.email@example.com"
```

#### Optional: Set up SSH Keys
```bash
# Generate SSH key
ssh-keygen -t rsa -b 4096 -C "your.email@example.com"

# Add SSH key to ssh-agent
ssh-add ~/.ssh/id_rsa

# Copy public key and add to GitHub
cat ~/.ssh/id_rsa.pub
```

## Quick Setup Verification

### Test All Tools
Run these commands to verify all tools are properly installed:

```bash
# Java
java -version
javac -version

# Maven
mvn -version

# Git
git --version

# Jenkins (check if service is running)
# Open http://localhost:8080 in browser
```

### Test Maven Build
Navigate to the project directory and run:
```bash
cd "DevOps-Lab4-M4M5"
mvn clean compile
mvn test
mvn package
```

Expected Maven output:
```
[INFO] Scanning for projects...
[INFO] Building DevOps Lab 4 - Continuous Build and Integration 1.0.0
[INFO] BUILD SUCCESS
[INFO] Total time: XX.XXX s
```

## Troubleshooting Common Issues

### Issue 1: JAVA_HOME not set
**Error**: `JAVA_HOME environment variable is not set`
**Solution**: Set JAVA_HOME environment variable to JDK installation path

### Issue 2: Maven command not found
**Error**: `'mvn' is not recognized as an internal or external command`
**Solution**: Add Maven's bin directory to system PATH

### Issue 3: Git command not found
**Error**: `'git' is not recognized as an internal or external command`
**Solution**: Install Git and ensure it's added to PATH during installation

### Issue 4: Jenkins not starting
**Error**: Jenkins service fails to start
**Solution**: 
- Check if port 8080 is already in use
- Run Jenkins on different port: `java -jar jenkins.war --httpPort=8090`
- Check Windows services for Jenkins

### Issue 5: Permission denied errors
**Error**: Permission issues during installation
**Solution**: Run command prompt or PowerShell as Administrator

## Environment Variables Summary

After installation, verify these environment variables are set:

| Variable | Example Value | Description |
|----------|---------------|-------------|
| JAVA_HOME | `C:\Program Files\Java\jdk-11.0.x` | JDK installation path |
| M2_HOME | `C:\Program Files\Apache\maven\apache-maven-3.8.6` | Maven installation path |
| PATH | Includes JDK/bin, Maven/bin, Git/bin | System PATH variable |

## Alternative Installation Methods

### Using Package Managers

#### Chocolatey (Windows)
```bash
# Install Chocolatey first, then:
choco install openjdk11
choco install maven
choco install git
choco install jenkins
```

#### Winget (Windows 10/11)
```bash
winget install Microsoft.OpenJDK.11
winget install Apache.Maven
winget install Git.Git
winget install Jenkins.Jenkins
```

### Using IDEs
- **IntelliJ IDEA**: Includes Maven and can manage JDK
- **Eclipse**: Includes Maven integration
- **Visual Studio Code**: Extensions for Java, Maven, Git

## Docker Alternative (Advanced)

If you prefer containerized setup:

```bash
# Jenkins with Docker
docker run -p 8080:8080 -p 50000:50000 jenkins/jenkins:lts

# Maven with Docker (for building)
docker run -it --rm -v "$(pwd)":/usr/src/mymaven -w /usr/src/mymaven maven:3.8-openjdk-11 mvn clean install
```

## Next Steps

After completing the installation:

1. ✅ Verify all tools are working
2. ✅ Clone or create the lab project
3. ✅ Test Maven build locally
4. ✅ Start Jenkins and access the web interface
5. ✅ Begin Task 1 of the lab assignment

## Support Resources

- **Java**: [Oracle JDK Documentation](https://docs.oracle.com/en/java/)
- **Maven**: [Apache Maven Documentation](https://maven.apache.org/guides/)
- **Git**: [Git Documentation](https://git-scm.com/doc)
- **Jenkins**: [Jenkins User Documentation](https://www.jenkins.io/doc/)
- **GitHub**: [GitHub Documentation](https://docs.github.com/)

---

**Note**: This setup guide ensures you have all the necessary tools installed and configured for the DevOps Lab 4 assignment. Make sure to test each tool before proceeding with the lab tasks.
