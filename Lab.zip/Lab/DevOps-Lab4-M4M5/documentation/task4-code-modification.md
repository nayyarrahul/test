# Task 4: Perform Continuous Integration through Jenkins by Modifying Source Code

## Objective
Demonstrate the complete continuous integration workflow by modifying source code in the Git repository and observing automatic build triggers in Jenkins.

## Prerequisites
- Task 1 completed (Git repository with source code)
- Task 2 completed (Jenkins build job working)
- Task 3 completed (CI polling configured)
- Jenkins actively polling every minute
- Git Polling Log showing "No changes" entries

## Understanding the CI Workflow

When you modify and push code to GitHub:
1. Developer makes changes to source code
2. Developer commits and pushes changes to GitHub
3. Jenkins polls GitHub and detects changes
4. Jenkins automatically triggers a new build
5. Build process runs (compile, test, package)
6. Build results are available in Jenkins
7. Developers are notified of build status

## Step-by-Step Instructions

### Step 4a: Prepare for Code Modification

#### 1. Verify Current CI Status
1. Check Jenkins job is polling (Git Polling Log shows recent entries)
2. Note the current build number (e.g., Build #1)
3. Ensure last build was successful

#### 2. Open Your Local Repository
Navigate to your project directory:
```bash
cd "C:\Users\rn185110\OneDrive - NCR ATLEOS\MyProjects\Lab\DevOps-Lab4-M4M5"
```

### Step 4b: Modification 1 - Update Application Version

#### 1. Edit Application.java
Open `src/main/java/com/devops/lab/Application.java` and modify the main method:

**Find this line:**
```java
System.out.println("Build Version: 1.0.0");
```

**Replace with:**
```java
System.out.println("Build Version: 1.1.0 - CI Demo Update");
```

#### 2. Add New Feature - Current Time Display
**Find this line:**
```java
System.out.println("Build Date: " + java.time.LocalDateTime.now());
```

**Replace with:**
```java
System.out.println("Build Date: " + java.time.LocalDateTime.now());
System.out.println("🚀 Continuous Integration is working!");
System.out.println("⏰ Last updated: " + java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(java.time.LocalDateTime.now()));
```

#### 3. Commit and Push Changes
```bash
# Check what files have changed
git status

# Add the modified file
git add src/main/java/com/devops/lab/Application.java

# Commit with descriptive message
git commit -m "Update application version to 1.1.0 and add CI demo features"

# Push to GitHub
git push origin main
```

### Step 4c: Monitor Jenkins for Automatic Build

#### 1. Watch Jenkins Job Page
1. Go to Jenkins job page: `http://localhost:8080/job/DevOps-Lab4-Build/`
2. Monitor the page for new build activity
3. Within 1-2 minutes, you should see a new build starting

#### 2. Observe Build Trigger
- New build should appear in Build History (e.g., Build #2)
- Build should be triggered by "SCM change"
- Status should show building progress

#### 3. Check Git Polling Log
1. Click "Git Polling Log"
2. Look for recent entry showing "Changes found"
3. Example log entry:
```
Started on [timestamp]
Using strategy: Default
[poll] Last Built Revision: Revision abc123 (origin/main)
[poll] Latest Remote Revision: Revision def456 (origin/main)
Changes found
Done. Took 1.2 sec
```

### Step 4d: Modification 2 - Add New Calculator Method

#### 1. Add New Method to Calculator.java
Open `src/main/java/com/devops/lab/Calculator.java` and add this method at the end of the class:

```java
/**
 * Calculates the percentage of a number
 * 
 * @param value The value to calculate percentage of
 * @param percentage The percentage to calculate
 * @return The percentage value
 */
public double calculatePercentage(double value, double percentage) {
    logger.debug("Calculating {}% of {}", percentage, value);
    
    if (percentage < 0) {
        logger.warn("Negative percentage provided: {}", percentage);
    }
    
    double result = (value * percentage) / 100.0;
    logger.debug("Percentage calculation result: {}", result);
    return result;
}
```

#### 2. Update Application.java to Use New Method
In the `demonstrateCalculator` method, add:

```java
// Add this after the division example
System.out.println("Percentage: 20% of " + a + " = " + calculator.calculatePercentage(a, 20));
```

#### 3. Add Test for New Method
Open `src/test/java/com/devops/lab/CalculatorTest.java` and add:

```java
@Test
@DisplayName("Test Calculate Percentage - Normal Case")
void testCalculatePercentageNormalCase() {
    // Given
    double value = 100.0;
    double percentage = 25.0;
    
    // When
    double result = calculator.calculatePercentage(value, percentage);
    
    // Then
    assertEquals(25.0, result, 0.001, "25% of 100 should equal 25");
}

@Test
@DisplayName("Test Calculate Percentage - Zero Percentage")
void testCalculatePercentageZero() {
    // Given
    double value = 50.0;
    double percentage = 0.0;
    
    // When
    double result = calculator.calculatePercentage(value, percentage);
    
    // Then
    assertEquals(0.0, result, 0.001, "0% of any number should equal 0");
}
```

#### 4. Commit and Push Second Set of Changes
```bash
# Check modified files
git status

# Add all modified files
git add .

# Commit with descriptive message
git commit -m "Add percentage calculation feature with tests - CI demonstration"

# Push to GitHub
git push origin main
```

### Step 4e: Monitor Second Automatic Build

#### 1. Observe Build #3 (or next build number)
- Should trigger within 1-2 minutes
- Monitor console output during build
- Verify all tests pass including new ones

#### 2. Verify Test Results
Check that the console output shows:
```
Tests run: 35, Failures: 0, Errors: 0, Skipped: 0
```
(33 original tests + 2 new tests)

### Step 4f: Modification 3 - Introduce a Deliberate Test Failure

#### 1. Create a Failing Test (To Demonstrate CI Failure Detection)
Add this test to `CalculatorTest.java`:

```java
@Test
@DisplayName("Test Intentional Failure - For CI Demo")
void testIntentionalFailure() {
    // This test is designed to fail to demonstrate CI failure detection
    // Comment out the next line after observing the build failure
    fail("This is an intentional failure to demonstrate CI failure detection");
    
    // Uncomment this line and comment out the fail() line to fix the test
    // assertTrue(true, "This test passes when the failure is fixed");
}
```

#### 3. Commit and Push Failing Test
```bash
git add .
git commit -m "Add intentional test failure for CI demonstration"
git push origin main
```

#### 4. Monitor Failed Build
1. Watch for build #4 (or next number)
2. Build should fail with red ball indicator
3. Console output should show test failure details

### Step 4g: Fix the Failing Test

#### 1. Fix the Test
Edit the failing test in `CalculatorTest.java`:

```java
@Test
@DisplayName("Test Intentional Failure - For CI Demo")
void testIntentionalFailure() {
    // This test is designed to fail to demonstrate CI failure detection
    // fail("This is an intentional failure to demonstrate CI failure detection");
    
    // Uncomment this line and comment out the fail() line to fix the test
    assertTrue(true, "This test passes when the failure is fixed");
}
```

#### 2. Commit and Push Fix
```bash
git add .
git commit -m "Fix intentional test failure - CI recovery demonstration"
git push origin main
```

#### 3. Monitor Recovery Build
- Build should succeed again (green ball)
- All tests should pass

## Verification and Analysis

### Build History Analysis
After completing all modifications, your build history should show:
1. **Build #1**: Initial manual build (blue ball - success)
2. **Build #2**: Auto-triggered by version update (blue ball - success)
3. **Build #3**: Auto-triggered by percentage feature (blue ball - success)
4. **Build #4**: Auto-triggered by failing test (red ball - failure)
5. **Build #5**: Auto-triggered by test fix (blue ball - success)

### Console Output Analysis
Compare console outputs across builds:
- **Successful builds**: "BUILD SUCCESS" message
- **Failed build**: "BUILD FAILURE" with test failure details
- **Test count progression**: 33 → 33 → 35 → 36 → 36 tests

### Git Integration Analysis
Git Polling Log should show:
- Multiple "Changes found" entries
- Corresponding timestamps with build triggers
- Different commit hashes for each change

## Advanced CI Scenarios (Optional)

### Scenario 1: Multiple Commits Before Build
1. Make several commits rapidly
2. Observe how Jenkins handles multiple changes
3. Note which commit triggers the build

### Scenario 2: Parallel Development Simulation
1. Create a feature branch
2. Configure Jenkins to monitor all branches
3. Test parallel development workflow

### Scenario 3: Build Performance Analysis
1. Monitor build duration across different changes
2. Identify performance bottlenecks
3. Optimize build process if needed

## Expected Outcomes Summary

| Build # | Trigger | Changes | Result | Tests |
|---------|---------|---------|--------|-------|
| 1 | Manual | Initial code | ✅ Success | 33 |
| 2 | SCM Change | Version update | ✅ Success | 33 |
| 3 | SCM Change | New feature + tests | ✅ Success | 35 |
| 4 | SCM Change | Failing test | ❌ Failure | 35 (1 failed) |
| 5 | SCM Change | Test fix | ✅ Success | 36 |

## Troubleshooting Common Issues

### Issue 1: Build Not Triggering
**Symptoms**: Git changes pushed but no new build
**Solution**:
- Check Git Polling Log for errors
- Verify polling schedule is active
- Confirm repository URL is correct

### Issue 2: Build Fails Due to Compilation Errors
**Symptoms**: Build fails during compile phase
**Solution**:
- Review console output for compilation errors
- Fix syntax errors in code
- Ensure all imports are correct

### Issue 3: Test Failures in CI vs Local
**Symptoms**: Tests pass locally but fail in Jenkins
**Solution**:
- Check Java version consistency
- Verify all dependencies are available
- Review environment-specific configurations

### Issue 4: Git Authentication Issues
**Symptoms**: "Authentication failed" in Git Polling Log
**Solution**:
- Verify Git credentials in Jenkins
- Check repository access permissions
- Test Git connectivity from Jenkins server

## Screenshots to Take

1. **Before modifications**: Jenkins job page showing latest build
2. **First code change**: Git commit command and push
3. **Build #2 triggering**: Jenkins showing new build starting
4. **Build #2 console output**: Successful build with updated version
5. **Second modification**: Adding percentage feature
6. **Build #3 results**: Successful build with increased test count
7. **Failing test commit**: Git push of intentional failure
8. **Build #4 failure**: Red ball showing failed build
9. **Build #4 console output**: Test failure details
10. **Test fix commit**: Git push of fix
11. **Build #5 recovery**: Green ball showing recovery
12. **Git Polling Log**: Multiple "Changes found" entries
13. **Final build history**: All builds showing complete CI workflow

## Task 4 Completion Checklist

- [ ] Application.java version updated and pushed
- [ ] Build #2 automatically triggered and successful
- [ ] Calculator percentage method added with tests
- [ ] Build #3 automatically triggered and successful
- [ ] Intentional test failure added and pushed
- [ ] Build #4 automatically triggered and failed appropriately
- [ ] Test failure fixed and pushed
- [ ] Build #5 automatically triggered and successful
- [ ] Git Polling Log shows all change detections
- [ ] Build history shows complete CI workflow
- [ ] All screenshots captured
- [ ] Console outputs documented

## Learning Outcomes

By completing Task 4, you have demonstrated:

1. **Continuous Integration**: Automatic builds triggered by code changes
2. **Automated Testing**: Tests run automatically with each build
3. **Failure Detection**: CI system catches and reports failures immediately
4. **Recovery Process**: Quick feedback loop for fixing issues
5. **Version Control Integration**: Seamless Git and Jenkins integration
6. **Build Automation**: Complete build lifecycle without manual intervention

## Best Practices Demonstrated

1. **Frequent Commits**: Small, focused changes for better tracking
2. **Descriptive Commit Messages**: Clear communication of changes
3. **Test-Driven Development**: Adding tests with new features
4. **Failure Handling**: Intentional failure to test CI response
5. **Quick Recovery**: Fast identification and fixing of issues

## Real-World Applications

This CI setup demonstrates patterns used in professional development:
- **Feature Development**: Adding new functionality with tests
- **Quality Assurance**: Automated testing on every change
- **Risk Mitigation**: Early detection of integration issues
- **Team Collaboration**: Shared code repository with automatic builds
- **Delivery Acceleration**: Faster feedback loops for development teams

---

**Congratulations!** You have successfully implemented and demonstrated a complete continuous integration pipeline using Git, Jenkins, and Maven. This forms the foundation for modern DevOps practices in software development.
