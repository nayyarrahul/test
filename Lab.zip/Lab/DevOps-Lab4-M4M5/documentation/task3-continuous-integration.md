# Task 3: Perform Continuous Integration

## Objective
Configure Jenkins to automatically poll the Git repository for changes and trigger builds automatically, implementing true continuous integration.

## Prerequisites
- Task 1 completed (Git repository created)
- Task 2 completed (Jenkins build job created and working)
- Jenkins job "DevOps-Lab4-Build" successfully building

## Understanding Continuous Integration

Continuous Integration (CI) is a development practice where developers integrate code into a shared repository frequently. Each integration is verified by an automated build and test suite to detect integration errors quickly.

## Step-by-Step Instructions

### Step 3a: Open the Created Job in Jenkins

1. Navigate to Jenkins dashboard at `http://localhost:8080`
2. Click on the job name "DevOps-Lab4-Build" from the job list
3. You should see the job's main page with build history

### Step 3b: Configure Build Triggers

#### 1. Access Job Configuration
1. From the job page, click "Configure" in the left sidebar
2. This opens the job configuration page

#### 2. Navigate to Build Triggers Section
1. Scroll down to the "Build Triggers" section
2. You'll see several trigger options available

#### 3. Select "Poll SCM" Option
1. Check the checkbox next to "Poll SCM"
2. This enables Jenkins to periodically check the Git repository for changes

### Step 3c: Set Up Cron Job Schedule

#### 1. Understanding Cron Syntax
The cron syntax in Jenkins follows the format: `MINUTE HOUR DAY MONTH DAYOFWEEK`
- `* * * * *` means "every minute"
- Each asterisk represents:
  - 1st `*`: Minute (0-59)
  - 2nd `*`: Hour (0-23)
  - 3rd `*`: Day of month (1-31)
  - 4th `*`: Month (1-12)
  - 5th `*`: Day of week (0-7, where 0 and 7 are Sunday)

#### 2. Configure Poll SCM Schedule
1. In the "Schedule" text box under "Poll SCM", enter: `* * * * *`
2. This configuration tells Jenkins to check for changes every minute

#### 3. Alternative Schedules (for reference)
```
# Every 5 minutes
H/5 * * * *

# Every 15 minutes
H/15 * * * *

# Every hour
H * * * *

# Every day at 2 AM
0 2 * * *

# Every weekday at 8 AM
0 8 * * 1-5
```

#### 4. Jenkins Cron Extensions
Jenkins also supports some special syntax:
- `H` - Use hash of job name for load balancing
- `@hourly` - Once per hour
- `@daily` - Once per day
- `@weekly` - Once per week

### Step 3d: Save the Job Configuration

1. Scroll to the bottom of the configuration page
2. Click "Save" to apply the changes
3. You'll be redirected back to the job's main page

### Step 3e: Observe Git Poll Log

#### 1. Access Poll Log
1. From the job's main page, look for "Git Polling Log" in the left sidebar
2. Click on "Git Polling Log"
3. This shows the polling activity and results

#### 2. Initial Poll Log Entry
You should see entries similar to:
```
Started on [timestamp]
Using strategy: Default
[poll] Last Built Revision: Revision [commit-hash] (origin/main)
[poll] Latest Remote Revision: Revision [commit-hash] (origin/main)
No changes
Done. Took [time]
```

#### 3. Understanding Poll Log Messages
- **"No changes"**: Repository hasn't changed since last build
- **"Changes found"**: New commits detected, build will be triggered
- **"Failed to connect"**: Network or repository access issues

### Step 3f: Monitor Continuous Integration

#### 1. Verify Polling is Active
1. Wait for 1-2 minutes after saving the configuration
2. Check the "Git Polling Log" again
3. You should see new entries every minute showing Jenkins is checking for changes

#### 2. Build History Updates
- Initially, no new builds will be triggered (no changes in repository)
- The polling log will show "No changes" entries every minute

## Testing Continuous Integration

### Test 1: Verify Polling Without Changes
1. Wait for 5 minutes after configuration
2. Check Git Polling Log - should show multiple "No changes" entries
3. Build history should remain unchanged

### Test 2: Prepare for Change Detection (Task 4 Preview)
The CI setup is now ready to detect changes. In Task 4, we'll modify code to trigger automatic builds.

## Advanced Configuration Options

### 1. Poll SCM with Specific Branches
In the SCM configuration, you can specify which branches to monitor:
- Branch Specifier: `*/main` (monitors only main branch)
- Branch Specifier: `*/develop` (monitors only develop branch)
- Branch Specifier: `*/*` (monitors all branches)

### 2. Ignore Commits from Certain Authors
You can configure Jenkins to ignore commits from specific users (useful for automated commits):
```
# In Additional Behaviours section of Git SCM
Add -> "Polling ignores commits in certain paths"
Add -> "Polling ignores commits from certain users"
```

### 3. Webhooks vs Polling
**Polling Approach (Current)**:
- Jenkins actively checks repository for changes
- Creates network traffic even when no changes exist
- Reliable but less efficient

**Webhook Approach (Alternative)**:
- GitHub notifies Jenkins when changes occur
- More efficient, immediate builds
- Requires Jenkins to be accessible from internet

## Monitoring CI Performance

### 1. Build Trends
- Monitor build frequency
- Track build success/failure rates
- Observe build duration trends

### 2. Resource Usage
- CPU usage during polling
- Network bandwidth for Git operations
- Disk space for build artifacts

### 3. Notification Setup (Optional)
Configure email notifications:
1. Go to "Manage Jenkins" → "Configure System"
2. Set up SMTP server details
3. In job configuration, add "Email Notification" post-build action

## Troubleshooting Common Issues

### Issue 1: Polling Not Working
**Symptoms**: No entries in Git Polling Log
**Solution**:
- Verify cron syntax is correct
- Check Jenkins system logs for errors
- Ensure Git repository URL is accessible

### Issue 2: Authentication Failures
**Symptoms**: "Failed to connect" in polling log
**Solution**:
- Verify Git credentials in Jenkins
- Check repository permissions
- Test Git URL accessibility from Jenkins server

### Issue 3: High CPU Usage
**Symptoms**: Jenkins server slow, high CPU usage
**Solution**:
- Reduce polling frequency (e.g., `H/5 * * * *` instead of `* * * * *`)
- Consider using webhooks instead of polling
- Monitor system resources

### Issue 4: Network Connectivity Issues
**Symptoms**: Intermittent polling failures
**Solution**:
- Check network connectivity to GitHub
- Verify proxy settings if applicable
- Consider increasing Git timeout settings

## Expected Git Polling Log Entries

### Successful Polling (No Changes)
```
Started on Dec 15, 2023 10:05:00 AM
Using strategy: Default
[poll] Last Built Revision: Revision abc123def456 (origin/main)
[poll] Latest Remote Revision: Revision abc123def456 (origin/main)
No changes
Done. Took 2.3 sec
```

### Successful Polling (Changes Found)
```
Started on Dec 15, 2023 10:06:00 AM
Using strategy: Default
[poll] Last Built Revision: Revision abc123def456 (origin/main)
[poll] Latest Remote Revision: Revision def789ghi012 (origin/main)
Changes found
Done. Took 1.8 sec
```

## Screenshots to Take

1. Jenkins job configuration page showing Build Triggers section
2. Poll SCM configuration with cron schedule
3. Saved job configuration confirmation
4. Git Polling Log showing first entries
5. Git Polling Log after several polling cycles
6. Build history before any automatic builds

## Task 3 Completion Checklist

- [ ] Jenkins job "DevOps-Lab4-Build" opened in configuration mode
- [ ] "Poll SCM" option selected in Build Triggers
- [ ] Cron schedule `* * * * *` configured
- [ ] Job configuration saved successfully
- [ ] Git Polling Log accessible and showing entries
- [ ] Polling activity verified (multiple "No changes" entries)
- [ ] System monitoring setup (optional)
- [ ] Screenshots taken and documented

## Expected Outcomes

1. ✅ Jenkins polls Git repository every minute
2. ✅ Git Polling Log shows regular polling activity
3. ✅ "No changes" messages appear in polling log (initially)
4. ✅ No builds triggered yet (no repository changes)
5. ✅ Continuous integration infrastructure ready
6. ✅ System ready to detect and build code changes automatically

## Understanding the CI Workflow

```
Developer → Git Commit → GitHub Repository → Jenkins Polling → 
Change Detection → Automatic Build → Test Execution → 
Build Results → Notifications (optional)
```

## Performance Considerations

### Polling Frequency Guidelines
- **Development Environment**: Every 1-5 minutes
- **Production Environment**: Every 15-30 minutes
- **Critical Systems**: Use webhooks for immediate response

### Resource Impact
- **Network**: ~1 KB per poll operation
- **CPU**: Minimal during polling, high during builds
- **Storage**: Build artifacts accumulate over time

## Next Steps

After completing Task 3, proceed to Task 4 where you'll modify the source code in the Git repository to trigger automatic builds and observe the complete continuous integration workflow in action.

---

**Important Notes**:
- Polling frequency of every minute is for demonstration purposes
- In production, use longer intervals or webhooks
- Monitor system resources when using frequent polling
- Git Polling Log is essential for troubleshooting CI issues
