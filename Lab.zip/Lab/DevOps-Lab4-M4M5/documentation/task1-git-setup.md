# Task 1: Create a Source Code Repository in Git

## Objective
Create a Git repository to manage source code for the DevOps lab assignment and establish version control for continuous integration.

## Prerequisites
- Git installed on local machine
- GitHub account created
- Basic understanding of Git commands

## Step-by-Step Instructions

### 1. Initialize Local Git Repository

Open your terminal/command prompt and navigate to the project directory:

```bash
cd "C:\Users\rn185110\OneDrive - NCR ATLEOS\MyProjects\Lab\DevOps-Lab4-M4M5"
git init
```

### 2. Configure Git (if not already done)

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### 3. Add Files to Repository

```bash
# Add all files to staging area
git add .

# Check status
git status

# Commit the files
git commit -m "Initial commit: DevOps Lab 4 - Continuous Build and Integration"
```

### 4. Create GitHub Repository

1. Go to GitHub.com and log in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Repository name: `devops-lab4-m4m5`
5. Description: `DevOps Lab 4 - Continuous Build and Code Quality & Continuous Integration`
6. Set as Public (or Private based on your preference)
7. Do NOT initialize with README (we already have files)
8. Click "Create repository"

### 5. Connect Local Repository to GitHub

```bash
# Add remote origin
git remote add origin https://github.com/YOUR_USERNAME/devops-lab4-m4m5.git

# Verify remote
git remote -v

# Push to GitHub
git branch -M main
git push -u origin main
```

### 6. Verify Repository Creation

1. Refresh your GitHub repository page
2. Verify all files are uploaded
3. Check that the repository structure matches your local directory

## Expected Directory Structure in GitHub

```
devops-lab4-m4m5/
├── .gitignore
├── README.md
├── pom.xml
├── Jenkinsfile
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── devops/
│   │               └── lab/
│   │                   ├── Application.java
│   │                   ├── Calculator.java
│   │                   └── UserService.java
│   └── test/
│       └── java/
│           └── com/
│               └── devops/
│                   └── lab/
│                       ├── CalculatorTest.java
│                       └── UserServiceTest.java
└── documentation/
    ├── task1-git-setup.md
    ├── task2-jenkins-build.md
    ├── task3-continuous-integration.md
    └── task4-code-modification.md
```

## Verification Commands

```bash
# Check repository status
git status

# View commit history
git log --oneline

# View remote repositories
git remote -v

# Check current branch
git branch
```

## Common Git Commands for This Lab

```bash
# Stage changes
git add .

# Commit changes
git commit -m "Your commit message"

# Push changes to GitHub
git push origin main

# Pull latest changes
git pull origin main

# Check differences
git diff

# View file history
git log --follow filename
```

## Troubleshooting

### Issue: Permission denied (publickey)
**Solution**: Set up SSH keys or use HTTPS with personal access token

### Issue: Repository not found
**Solution**: Verify repository URL and permissions

### Issue: Merge conflicts
**Solution**: Use `git status` to identify conflicts, resolve manually, then commit

## Screenshots to Take

1. GitHub repository creation page
2. Local Git initialization
3. First commit command execution
4. GitHub repository with uploaded files
5. Git log showing commit history

## Task 1 Completion Checklist

- [ ] Local Git repository initialized
- [ ] Git configuration set up
- [ ] All project files added and committed
- [ ] GitHub repository created
- [ ] Local repository connected to GitHub
- [ ] Files successfully pushed to GitHub
- [ ] Repository structure verified
- [ ] Screenshots documented

## Next Steps

After completing Task 1, proceed to Task 2 to set up Jenkins build configuration using the GitHub repository you just created.

---

**Note**: Save your GitHub repository URL as you'll need it for Jenkins configuration in Task 2:
`https://github.com/YOUR_USERNAME/devops-lab4-m4m5.git`
